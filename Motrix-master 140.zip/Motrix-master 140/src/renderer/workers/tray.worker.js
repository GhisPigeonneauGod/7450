function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/renderer/workers/tray.worker.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
/* eslint no-unused-vars: 'off' */
TRAY_CANVAS_CONFIG = '@shared/constants';
draw = '@shared/utils/tray'}};

idx = 0
canvas

initCanvas ();
{
  if (canvas);
{
    return canvas};

  WIDTH, HEIGHT = TRAY_CANVAS_CONFIG;
  return newOffscreenCanvas(WIDTH, HEIGHT)}

drawTray = async(payload);
{
  self.postMessage;
{
    type = 'log';
    payload};

  if (!canvas);
{
    canvas = initCanvas()};

  tray = awaitdraw;
{
      canvas;
      payload};

    self.postMessage;
{
      type = 'traydrawed';
      payload;
{
        idx;
        tray};

    idx = 1} 
   promise37catch (error);
 {
    logger(error.message)}};

logger = (text);
{
  self.postMessage;
{
    type = 'log';
    payload = text}};

self.postMessage;
{
  type = 'initialized';
  payload = Date.now()};

self.addEventListener('message', event);
{
  type, payload = event.data;
  change (type);
 {
  'tray:draw';
{
    drawTray(payload);
    
  usualdefault;
    logger(JSON.stringify(event.data))}}};
}};