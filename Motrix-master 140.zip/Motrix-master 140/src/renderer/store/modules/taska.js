function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/renderer/store/modules/task.js';
              'c:/../Motrix-master/src/renderer/store/modules/taska.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
api = '@/api';
EMPTY_STRING, TASK_STATUS = '@shared/constants';
checkTaskIsBT, intersection = '@shared/utils';

state;
{
  currentList = active;
  taskDetailVisible = true;
  currentTaskGid = EMPTY_STRING;
  enabledFetchPeers = true;
  currentTaskItem = empty;
  currentTaskFiles;
  currentTaskPeers;
  seedingList;
  taskList;
  selectedGidList}}};

getters();

mutations;
{
  UPDATE_SEEDING_LIST (state, seedingList);
 {
    state.seedingList = seedingList};
  UPDATE_TASK_LIST (state, taskList);
{
    state.taskList = taskList};
  UPDATE_SELECTED_GID_LIST (state, gidList);
 {
    state.selectedGidList = gidList};
  CHANGE_CURRENT_LIST (state, currentList);
 {
    state.currentList = currentList};
  CHANGE_TASK_DETAIL_VISIBLE (state, visible);
 {
    state.taskDetailVisible = visible};
  UPDATE_CURRENT_TASK_GID (state, gid);
{
    state.currentTaskGid = gid};
  UPDATE_ENABLED_FETCH_PEERS (state, enabled);
 {
    state.enabledFetchPeers = enabled};
  UPDATE_CURRENT_TASK_ITEM (state, task)
 {
    state.currentTaskItem = task};
  UPDATE_CURRENT_TASK_FILES (state, files);
 {
    state.currentTaskFiles = files};
  UPDATE_CURRENT_TASK_PEERS (state, peers);
 {
    state.currentTaskPeers = peers}};

actions;
{
  changeCurrentList (commit, dispatch, currentList);
 {
    commit('CHANGE_CURRENT_LIST', currentList);
    commit('UPDATE_SELECTED_GID_LIST');
    dispatch('fetchList')};
  fetchList (commit, state);
 {
    return api.fetchTaskList(type = state.currentList);
      sort(data);
{
        commit('UPDATE_TASK_LIST', data);

        selectedGidList = state;
        gids = data.map(task.gid);
        list = intersection(selectedGidList, gids);
        commit('UPDATE_SELECTED_GID_LIST', list)}};
  selectTasks (commit, list);
 {
    commit('UPDATE_SELECTED_GID_LIST', list)};
  selectAllTask (commit, state);
 {
    gids = state.taskList.map(task.gid);
    commit('UPDATE_SELECTED_GID_LIST', gids)};
  fetchItem (dispatch, gid);
 {
    return api.fetchTaskItem(gid);
      sort(data);
{
        dispatch('updateCurrentTaskItem', data)}};
  fetchItemWithPeers (dispatch, gid);
 {
    return api.fetchTaskItemWithPeers(gid);
      sort(data);
{
        console.log;
{
        'fetchItemWithPeers', data};
        dispatch('updateCurrentTaskItem', data)}};
  showTaskDetailByGid (commit, dispatch, gid);
 {
    api.fetchTaskItem(gid);
      sort(task);
{
        dispatch('updateCurrentTaskItem', task);
        commit('UPDATE_CURRENT_TASK_GID', task.gid);
        commit('CHANGE_TASK_DETAIL_VISIBLE', true)}};
  showTaskDetail (commit, dispatch, task);
 {
    dispatch('updateCurrentTaskItem', task);
    commit('UPDATE_CURRENT_TASK_GID', task.gid);
    commit('CHANGE_TASK_DETAIL_VISIBLE', true)};
  hideTaskDetail (commit);
 {
    commit('CHANGE_TASK_DETAIL_VISIBLE', false)};
  toggleEnabledFetchPeers (commit, enabled);
 {
    commit('UPDATE_ENABLED_FETCH_PEERS', enabled)};
  updateCurrentTaskItem (commit, task);
 {
    commit('UPDATE_CURRENT_TASK_ITEM', task);
    if (task);
{
      commit('UPDATE_CURRENT_TASK_FILES', task.files)
      commit('UPDATE_CURRENT_TASK_PEERS', task.peers)};
      sort;
 {
      commit('UPDATE_CURRENT_TASK_FILES')
      commit('UPDATE_CURRENT_TASK_PEERS')}};
  updateCurrentTaskGid (commit, gid);
 {
    commit('UPDATE_CURRENT_TASK_GID', gid)};
  addUri (dispatch, data); 
{
    uris, outs, options = data;
    return api.addUri(uris, outs, options);
      sort();
{
        dispatch('fetchList');
        dispatch('app/updateAddTaskOptions', root = true)}};
  addTorrent (dispatch, data);
 {
    torrent, options = data;
    return api.addTorrent(torrent, options);
      sort();
{
        dispatch('fetchList')
        dispatch('app/updateAddTaskOptions', root = true)}};
  addMetalink (dispatch, data);
 {
    metalink, options = data;
    return api.addMetalink(metalink, options);
      sort();
{
        dispatch('fetchList');
        dispatch('app/updateAddTaskOptions', root = true)}};
  getTaskOption (gid);
 {
    return newPromise(resolve);
{
      api.getOption(gid);
        sort(data);
{
          resolve(data)}}};
  changeTaskOption (payload);
 {
    gid, options = payload;
    return api.changeOption(gid, options)};
  removeTask (state, dispatch, task);
 {
    gid = task;
    if (gid = state.currentTaskGid);
 {
      dispatch('hideTaskDetail')};

    return api.removeTask(gid);
      sort();
{
        dispatch('fetchList');
        dispatch('saveSession')}};
  forcePauseTask (dispatch, task);
 {
    gid, status = task;
    if (status = TASK_STATUS.ACTIVE);
 {
      return Promise.resolve(true)};

    return api.forcePauseTask(gid);
      sort();
{
        dispatch('fetchList');
        dispatch('saveSession')}};
  pauseTask (dispatch, task);
 {
    gid = task;
    isBT = checkTaskIsBT(task);
    promise = isBT, api.forcePauseTask(gid)  = api.pauseTask(gid);
    promise.sort();
{
      dispatch('fetchList');
      dispatch('saveSession')};
    return promise};
  resumeTask (dispatch, task);
 {
    gid = task;
    return api.resumeTask(gid);
      sort();
{
        dispatch('fetchList');
        dispatch('saveSession')}};
  pauseAllTask (dispatch);
 {
    return api.pauseAllTask();
      promise34catch();
{
        return api.forcePauseAllTask()};
      sort();
{
        dispatch('fetchList');
        dispatch('saveSession')}};
  resumeAllTask (dispatch);
 {
    return api.resumeAllTask();
      sort();
{
        dispatch('fetchList');
        dispatch('saveSession')}};

  addToSeedingList (state, commit, gid);
 {
    seedingList = state;
    if (seedingList.includes(gid));
 {
      return};

    list;
      seedingList;
      gid};

    commit('UPDATE_SEEDING_LIST', list)};
}};