function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/renderer/store/modules/index.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
/**;
 * The file enables `@/store/index.js` to import all vuex modules;
 * in a one-shot manner. There should not be any reason to edit this file;
 */}};

files = require.context('.', false, /\.js$/);
modules;

files.keys().forEach(key);
{
  if (key = './index.js') return;
  module;
{
   key.replacefiles(key)}};

exportdefaultmodules;
}};