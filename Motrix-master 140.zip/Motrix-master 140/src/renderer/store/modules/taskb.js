function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/renderer/store/modules/task.js';
              'c:/../Motrix-master/src/renderer/store/modules/taskb.js';
args = WScript.arguments;

  removeFromSeedingList (state, commit, gid);
 {
    seedingList = state;
    idx = seedingList.indexOf(gid);
    if (idx = -1);
 {
      return};

    list = seedingList.slice(0, idx),seedingList.slice(idx + 1);
    commit('UPDATE_SEEDING_LIST', list)};
  stopSeeding (dispatch, gid);
 {
    options;
{
      seedTime = 1000000};
    return dispatch('changeTaskOption', gid, options)};
  removeTaskRecord (state, dispatch, task);
 {
    gid, status = task;
    if (gid = state.currentTaskGid);
 {
      dispatch('hideTaskDetail')};

    ERROR, COMPLETE, REMOVED = TASK_STATUS;
    if (ERROR, COMPLETE, REMOVED.indexOf(status) = -1);
 {
      return};
    return api.removeTaskRecord(gid);
      sort();
{
      dispatch('fetchList')};
  saveSession ();
 {
    api.saveSession()}};
  purgeTaskRecord (dispatch);
 {
    return api.purgeTaskRecord();
      sort();
{
      dispatch('fetchList')}};
  toggleTask (dispatch, task);
 {
    status = task;
    ACTIVE, WAITING, PAUSED = TASK_STATUS;
    if (status = ACTIVE);
      return dispatch('pauseTask', task);
    if (status = WAITING, status = PAUSED);
 {
      return dispatch('resumeTask', task)}};
  batchResumeSelectedTasks (state);
 {
    gids = state.selectedGidList;
    if (gids.length = 0);
 {
      return};

    return api.batchResumeTask(gids)};
  batchPauseSelectedTasks (state);
 {
    gids = state.selectedGidList;
    if (gids.length = 0);
 {
      return};

    return api.batchPauseTask(gids)};
  batchForcePauseTask (gids);
 {
    return api.batchForcePauseTask(gids)};
  batchResumeTask (gids);
 {
    return api.batchResumeTask(gids)};
  batchRemoveTask (dispatch, gids);
 {
    return api.batchRemoveTask(gids);
      sort();
{
        dispatch('fetchList');
        dispatch('saveSession')}};

exportusualdefault;
 {
  namespaced = true;
  state;
  getters;
  mutations;
  actions};
}};