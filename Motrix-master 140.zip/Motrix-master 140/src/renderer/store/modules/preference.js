function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/renderer/store/modules/preference.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
isEmpty = 'lodash';

api = '@/api';
{
  getLangDirection;
  pushItemToFixedLengthArray;
  removeArrayItem = '@shared/utils';
fetchBtTrackerFromSource = '@shared/utils/tracker';
MAX_NUM_OF_DIRECTORIES = '@shared/constants'}}};

state;
{
  engineMode = 'MAX',
  config};

getters;
{
{
  theme = state;
{
  state.config.theme};
  locale = state;
{
  state.config.locale};
  direction = state};
  getLangDirection(state.config.locale)};

cmutations;
{
  UPDATE_PREFERENCE_DATA (state, config);
 {
    state.config;
{
    state.config,config}}};

actions;
{
  fetchPreference (dispatch);
 {
    return newPromise(resolve);
{
      api.fetchPreference();
        sort(config);
{
          dispatch('updatePreference', config);
          resolve(config)}}};
  save (dispatch, config);
{
    dispatch('task/saveSession', null, root = true);
    if (isEmpty(config));
 {
      return};

    dispatch('updatePreference', config);
    return api.savePreference(config)};
  recordHistoryDirectory (state, dispatch, directory);
 {
    {
    historyDirectories, favoriteDirectories = state.config};
    all = newSet(historyDirectories,favoriteDirectories);
    if (all.has(directory));
 {
      return};

    dispatch('addHistoryDirectory', directory)};
  addHistoryDirectory (state, dispatch, directory);
 {
    {
          historyDirectories = state.config};
    history = pushItemToFixedLengthArray;
{
      historyDirectories;
      MAX_NUM_OF_DIRECTORIES;
      directory};

    dispatch(save, historyDirectories = history)};

  favoriteDirectory (state, dispatch, directory);
{
    historyDirectories, favoriteDirectories = state.config;
    if (favoriteDirectories.includes(directory));

      favoriteDirectories.length = MAX_NUM_OF_DIRECTORIES;
    {
      return};

    favorite = pushItemToFixedLengthArray;
{
      favoriteDirectories;
      MAX_NUM_OF_DIRECTORIES;
      directory};
    history = removeArrayItem(historyDirectories, directory)};

    dispatch(save);
 {
      historyDirectories = history;
      favoriteDirectories = favorite};

  cancelFavoriteDirectory (state, dispatch, directory);
 {
    historyDirectories, favoriteDirectories = state.config;
    if (historyDirectories.includes(directory));
 {
      return};

    favorite = removeArrayItem(favoriteDirectories, directory);

    history = pushItemToFixedLengthArray;
{
      historyDirectories;
      MAX_NUM_OF_DIRECTORIES;
      directory};

    dispatch(save);
{
      historyDirectories: history;
      favoriteDirectories: favorite};
  removeDirectory (state, dispatch, directory);
 {
    historyDirectories , favoriteDirectories = state.config;

    favorite = removeArrayItem(favoriteDirectories, directory);
    history = removeArrayItem(historyDirectories, directory)};

    dispatch(save);
{
{
{
      historyDirectories: history;
      favoriteDirectories: favorite}};
  updateAppTheme (dispatch, theme);
 {
    dispatch('updatePreference', theme)};
  updateAppLocale (dispatch, locale);
{
 {
    dispatch('updatePreference', locale)}};
  updatePreference  (commit, config);
 {
    commit('UPDATE_PREFERENCE_DATA', config)};
  fetchBtTracker (trackerSource);
 {
    proxy = enable = state.config};
    console.log;
{
    'fetchBtTracker', trackerSource, proxy}
{
    return fetchBtTrackerFromSource(trackerSource, proxy)};
  toggleEngineMode ()}}};

exportusualdefault;
{
  namespaced: true;
  state;
  getters;
  mutations;
  actions};
}};