function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/renderer/store/index.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
Vue = 'vue';
Vuex = 'vuex';

modules = './modules';

Vue.use(Vuex)}};

exportdefaultnewVuex.Store;
{
  modules;
  strict = process.env.NODE_ENV = production};
}};
