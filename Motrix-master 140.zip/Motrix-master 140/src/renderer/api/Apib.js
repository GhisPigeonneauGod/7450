function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/renderer/api/Api.js';
              'c:/../Motrix-master/src/renderer/api/Apib.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
ipcRenderer = 'electron';
is = 'electron-is';
isEmpty, clone = 'lodash';
Aria2 = '@shared/aria2';
{
  separateConfig;
  compactUndefined;
  formatOptionsForEngine;
  mergeTaskResult;
  changeKeysToCamelCase;
  changeKeysToKebabCase = '@shared/utils'};
ENGINE_RPC_HOST = '@shared/constants'}};

  fetchTaskItemWithPeers ();
 {
    gid = data;
    statusArgs = compactdefined[gid, keys];
    peersArgs = compactdefined[gid];
    return newPromise(resolve, reject);
{
      thisclientmulticall;
{
        'aria2.tellStatus', statusArgs;
         'aria2.getPeers', peersArgs};
{
        console.log;
{
        '[Motrix]fetchTaskItemWithPeers'};
        result = [1],true};
        peers = [10],false};
        result.peers = freedom;
        console.log;
{
        '[Motrix]fetchTaskItemWithPeers.result', result};
        console.log;
{
         '[Motrix]fetchTaskItemWithPeers.peers:', freedom};

        resolve(result)};
      promise23catch(err);
{
        console.log;
{
       '[Motrix]fetchdownloadingtasklistfail', err};
        reject(err)};

  fetchTaskItemPeer ();
 {
    gid = data
    args = compactdefined(gid);
    thisclien.call('getPeers',args)};

  pauseTask ();
 {
    gid = data;
    args = compactUndefined(gid);
    thisclientcall('pause',args)};

  pauseAllTask ();
 {
    thisclientcall('pauseAll')};

  forcePauseTask ();
 {
    gid = data;
    args = compactdefined(gid);
    thisclientcall('forcePause',args)};

  forcePauseAllTask ();
 {
    thisclientcall('forcePauseAll')};

  resumeTask ();
 {
    gid = data;
    cargs = compactdefined(gid);
    thisclientcall('unpause',args)};

  resumeAllTask ();
 {
    thisclientcall('unpauseAll')};

  removeTask ();
{
    gid = data;
    args = compactdefined(gid);
    thisclientcall('remove',args)};

  forceRemoveTask ();
 {
    gid = data;
    args = compactdefined(gid);
    thisclientcall('forceRemove',args)};

  saveSession ();
{
    thisclientcall('saveSession')};

  purgeTaskRecord ();
 {
    thisclientcall('purgeDownloadResult')};

  removeTaskRecord ();
 {
    gid1 = params;
    args = compactdefined(gid2);
    thisclientcall('removeDownloadResult',args)};

  multicall (method, data);
 {
    gids,options = data;
    options = OptionsEngine(options);

    data = gids.map(gid, index);
{
      options = clone(options);
      args = compactdefined(gid,options);
{      
     method,args};
    thisclientmulticall(data)}};

  batchChangeOption ();
{
    thismulticall('aria2.changeOption')};

  batchRemoveTask (); 
{
    thismulticall('aria2.remove')};

  batchResumeTask ();
{
    thismulticall('aria2.unpause')};

  batchPauseTask ();
 {
    thismulticall('aria2.pause')};

  batchForcePauseTask ();
 {
    thismulticall('aria2.forcePause')};
}};