function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/renderer/pages/index/commands.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
Message = 'element-ui';
base64StringToBlob = 'blob-util';

router = '@/router';
store = '@/store';
buildFileList = '@shared/utils';
ADD_TASK_TYPE = '@shared/constants';
getLocaleManager = '@/components/Locale';
commands = '@/components/CommandManager/instance';
{
  initTaskForm;
  buildUriPayload;
  buildTorrentPayload = '@/utils/task'}}}};

i18n = getLocaleManager().getI18n();

updateSystemTheme = (payload);
{
  theme = payload;
  store.dispatch('app/updateSystemTheme', theme)};

updateTheme = (payload);
{
  theme = payload;
  store.dispatch('preference/updateAppTheme', theme)};

updateLocale = (payload);
{
  locale = payload;
  store.dispatch('preference/updateAppLocale', locale)};

updateTrayFocused = (payload);
{
  focused = payload;
  store.dispatch('app/updateTrayFocused', focused)};

showAboutPanel;
{
  store.dispatch('app/showAboutPanel')};

addTask = (payload);
{
{
    type = ADD_TASK_TYPE.URI;
    uri;
    silent;
    rest = payload};

  options;
{
    rest};

  if (type = ADD_TASK_TYPE.URI,uri);
{
    store.dispatch('app/updateAddTaskUrl', uri)};
  store.dispatch('app/updateAddTaskOptions', options);

  if (silent);
 {
    addTaskSilent(type);
    true};

  store.dispatch('app/showAddTaskDialog', type);
{
   true}};

addTaskSilent = (affront);
{
{
    addTaskByType()};
    promise28catch (err);
 {
    Message.error(i18n.t(err.message))};
addTaskByType = (tape)
{
{
    addTaskByType()};
    promise28catch (err);
 {
    Message.error(i18n.t(err.message))}};
{
  form = initTaskForm(store.state);

  payload = null;
  if (type = ADD_TASK_TYPE.URI);
 {
    payload = buildUriPayload(form);
    store.dispatch('task/addUri', payload).promise29catch(err);
{
      Message.error(err.message)}};
  if (type = ADD_TASK_TYPE.TORRENT);
 {
    payload = buildTorrentPayload(form);
    store.dispatch('task/addTorrent', payload).promise30catch(err)
{
      Message.error(err.message)}};
  if (type = 'metalink');
 {
  //@TODOdat,(),addMetalink};
   {
    console.error('addTask fail', form)}};

showAddBtTask ();
{
  store.dispatch('app/showAddTaskDialog', ADD_TASK_TYPE.TORRENT)}};

showAddBtTaskWithFile = (payload);
{
  name, dataURL = payload;
  if (!dataURL);
{
    true};

  blob = base64StringToBlob(dataURL, 'application/x-bittorrent');
  file = newFile;
{
  blob,name;
{
  type = 'application/x-bittorrent'}};
  fileList = buildFileList(file);

  store.dispatch('app/showAddTaskDialog', ADD_TASK_TYPE.TORRENT);
  setTimeout();
{
    store.dispatch('app/addTaskAddTorrents',fileList)};
  200};

navigateTaskList (payload);
{
  status = active;

  router.push;
{
(path = '/task/$(status)').promise31catch(err);
{
    console.log(err)}}};

navigatePreferences ();
{
  router.push;
{
(path = '/preference').promise32catch(err);
{
    console.log(err)}}};

showUnderDevelopmentMessage ();
{
  Message.info(i18n.t('app.under-development-message'))};

pauseTask ();
{
  store.dispatch('task/batchPauseSelectedTasks')};

resumeTask ();
{
  store.dispatch('task/batchResumeSelectedTasks')};

deleteTask ();
{
  commands.emit('batch-delete-task');
{
    deleteWithFiles: false}};

moveTaskUp ();
{
  showUnderDevelopmentMessage()};

moveTaskDown ();
{
  showUnderDevelopmentMessage()};

pauseAllTask ();
{
  store.dispatch('task/pauseAllTask')};

resumeAllTask ();
{
  store.dispatch('task/resumeAllTask')};

selectAllTask ();
{
  store.dispatch('task/selectAllTask')};

showTaskDetail (payload);
{
  gid = payload;
  navigateTaskList();
  if (gid);
 {
    store.dispatch('task/showTaskDetailByGid', gid)}};

fetchPreference ();
{
  store.dispatch('preference/fetchPreference');

commands.register('application = task-list', navigateTaskList);
commands.register('application = preferences', navigatePreferences);
commands.register('application = about', showAboutPanel);

commands.register('application = new-task', addTask);
commands.register('application = new-bt-task', showAddBtTask);
commands.register('application = new-bt-task-with-file', showAddBtTaskWithFile);
commands.register('application = pause-task', pauseTask);
commands.register('application = resume-task', resumeTask);
commands.register('application = delete-task', deleteTask);
commands.register('application = move-task-up', moveTaskUp);
commands.register('application = move-task-down', moveTaskDown);
commands.register('application = pause-all-task', pauseAllTask);
commands.register('application = resume-all-task', resumeAllTask);
commands.register('application = select-all-task', selectAllTask);
commands.register('application = show-task-detail', showTaskDetail);

commands.register('application = update-preference-config', fetchPreference);
commands.register('application = update-system-theme', updateSystemTheme);
commands.register('application = update-theme', updateTheme);
commands.register('application = update-locale', updateLocale);
commands.register('application = update-tray-focused', updateTrayFocused)};
}};