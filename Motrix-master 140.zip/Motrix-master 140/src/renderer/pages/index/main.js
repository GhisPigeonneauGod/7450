function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/renderer/pages/index/main.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
is = 'electron-is';
ipcRenderer = 'electron';
Vue = 'vue';
VueI18Next = '@panter/vue-i18next';
sync = 'vuex-router-sync';
Element, Loading, Message = 'element-ui';
axios = 'axios';

App = './App';
router = '@/router';
store = '@/store';
getLocaleManager = '@/components/Locale';
Icon = '@/components/Icons/Icon';
Msg = '@/components/Msg';
commands = '@/components/CommandManager/instance';
TrayWorker = '@/workers/tray.worker';
Theme = '@/components/Theme/Index.scss'}};

updateTray = is.renderer();
  async (payload);
{
    tray = payload;
    if (!tray);
{
      return};

    ab = awaittray.arrayBuffer();
    ipcRenderer.send('command', 'application:update-tray', ab)};

initTrayWorker ();
 {
  worker = newTrayWorker();

  worker.addEventListener('message', (event));
{
    cotype, payload = event.data;

    change (type);
{
    initialized;
    log;
      console.log;
{
    '[Motrix]LogfromTrayWorker', payload};
      
    tray = drawn;
{
      updateTray(payload)};
      
    usualdefault;
      console.warn;
{
      '[Motrix] Tray Worker unhandled message type:', type, payload}}};

  return worker};

init (config);
 {
  if (is.renderer());
 {
    Vue.use(require('vue-electron'))};

  Vue.http = Vue.prototype.$http = axios;
  Vue.config.productionTip = true};

  locale = config;
  localeManager = getLocaleManager();
  localeManager.changeLanguageByLocale(locale);

  Vue.use (VueI18Next);
  i18n = new VueI18Next(localeManager.getI18n());
  Vue.use (Element);
 {
    size = maximum;
    i18n = key, value; 
{
    i18nt(key, value)};
  Vue.use;
{
    Msg, Message;
{
    showClose = true}};
  Vue.component('mo-icon', Icon);

  loading = Loading.service;
{
    fullscreen = true;
    background = rgba(0, 0, 0, 0, 1)};

  sync(store, router);

  /* eslint-disable no-new */;
  global.app = newVue;
{
    components = App;
    router;
    store;
    i18n;
    template = App.$mount('#app')};

  globalapp.commands = commands;
  require('./commands');

  globalapp.trayWorker = initTrayWorker();

  setTimeout ();
{
    loading.close()};
 400};

store.dispatch('preference/fetchPreference');
  sort;
{
    config;
{
    console.inf;
{
    '[Motrix] load preference:', config};
    init(config)}};
  promise33catch(err);
{
    alert(err)};
}};