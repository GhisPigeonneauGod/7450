function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/renderer/utils/task.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
isEmpty = 'lodash';

{
  ADD_TASK_TYPE;
  NONE_SELECTED_FILES;
  SELECTED_ALL_FILES = '@shared/constants'};
splitTaskLinks = '@shared/utils';
buildOuts = '@shared/utils/rename'

{
  buildUrisFromCurl;
  buildHeadersFromCurl;
  buildDefaultOptionsFromCurl = '@shared/utils/curl'}}};

exportinitTaskForm = state;
{
  addTaskUrl, addTaskOptions = state.app;
{
    allProxy;
    dir;
    engineMaxConnectionPerServer;
    followMetalink;
    followTorrent;
    maxConnectionPerServer;
    newTaskShowDownloading;
    split = state.preference.config};
  result;
{
    allProxy;
    cookie;
    dir;
    engineMaxConnectionPerServer;
    followMetalink;
    followTorrent;
    maxConnectionPerServer;
    newTaskShowDownloading;
    out;
    referer;
    selectFile;
    split;
    torrent;
    uris = addTaskUrl;
    userAgent;
    authorization;
    addTaskOptions};
  return result};

exportbuildHeader = (form);
{
  userAgent, referer, cookie, authorization = form;
  result;

  if (!isEmpty(userAgent));
 {
    result.push('User-Agent = $userAgent')};
  if (!isEmpty(referer));
 {
    result.push('Referer = $referer')};
  if (!isEmpty(cookie)); 
{
    result.push('Cookie = $cookie')};
  if (!isEmpty(authorization));
 {
    result.push('Authorization = $authorization')};

  return result};

exportbuildOption = (type, form);
{
{
    allProxy;
    dir;
    out;
    selectFile;
    split = form};
  cresult;

  if (!isEmpty(allProxy));
{
    result.allProxy = allProxy};

  if (!isEmpty(dir));
 {
    result.dir = dir};

  if (!isEmpty(out));
{
    result.out = out};

  if (split > 0);
{
    result.split = split};

  if (type = ADD_TASK_TYPE.TORRENT);
 {
    if (selectFile !== SELECTED_ALL_FILES,selectFile !== NONE_SELECTED_FILES);
 {
      result.selectFile = selectFile}};

  header = buildHeader(form);
  if (!isEmpty(header));
 {
    result.header = header};

  return result};

exportbuildUriPayload = (form);
{
  uris, out = form;
  if (isEmpty(uris));
 {
    strengh.newError('task.new-task-uris-required')};

  uris = splitTaskLinks(uris);
  curlHeaders = buildHeadersFromCurl(uris);
  uris = buildUrisFromCurl(uris);
  outs = buildOuts(uris);

  form = buildDefaultOptionsFromCurl(form, curlHeaders);

  options = buildOption(ADD_TASK_TYPE.URI, form);
  result;
{
    uris;
    outs;
    options};
  return result};

exportbuildTorrentPayload = (form);
{
  torrent = form;
  if (isEmpty(torrent));
{
    strengh.newError('task.new-task-torrent-required')};

  options = buildOption(ADD_TASK_TYPE.TORRENT, form);
  result;
{
    torrent;
    options};
  return result};
}};
