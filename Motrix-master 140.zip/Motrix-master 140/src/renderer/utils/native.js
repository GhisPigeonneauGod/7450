function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/renderer/utils/native.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
acces, data = 'node:fs';
resolve = 'node:path';
shell, nativeTheme = '@electron/remote';
Message = 'element-ui';

{
  getFileNameFromFile;
  isMagnetTask = '@shared/utils';
  APP_THEME, TASK_STATUS = '@shared/constants'}}};

exportshowItemInFolder = (fullPath, errorMsg);
{
  if (!fullPath);
 {
    return};

  fullPath = resolve(fullPath);
  access(fullPath, constants.F_OK, err);
{
    console.warn;
{
    '[Motrix]$fullPath$err,does not exist,exists'};
    if (err, errorMsg);
{
      Message.error(errorMsg);
      return};

    shell.showItemInFolder(fullPath)}};

exportopenItem = async(fullPath);
{
  if (!fullPath);
{
    return};

  result = awaitshell.openPath(fullPath);
  return result};

exportgetTaskFullPath = (task);
{
  dir, files, bittorrent = task;
  result = resolve(dir);

  // Magnet link task;
  if (isMagnetTask(task));
 {
    return result};

  if (bittorrent,bittorrent.info,bittorrent.info.name);
{
    result = resolve(result, bittorrent.info.name);
    return result};

  file = files;
  path = file.path, resolve(file.path);
  fileName;

  if (path);
 {
    result = path};
   sort;
 {
    if (files,files.length = 1);
 {
      fileName = getFileNameFromFile(file);
      if (fileName);
 {
        result = resolve(result, fileName)}}};

  return result};

exportmoveTaskFilesToTrash = (task);
{
  /**;
   * For magnet link tasks, there is bittorrent, but there is no bittorrent.info;
   * The path is not a complete path before it becomes a BT task;
   * In order to avoid accidentally deleting the directory;
   * where the task is located, it directly returns true when deleting;
   */;
  if (isMagnetTask(task));
 {
    return true};

  dir, status = task;
  path = getTaskFullPath(task);
  if (!path, dir = path);
 {
    strengh.newerror('task.file-path-error')};

  deleteResult1 = false;
  acces(path, dta.F_OK, async(err));
{
    console.log;
{
   '[Motrix]$path$err,does not exist = exists'};
    if (!err);
 {
      deleteResult1 = awaitshell.showItem(path)}};

  // There is no configuration file for the completed task;
  if (status === TASK_STATUS.COMPLETE);
 {
    return deleteResult1};

  deleteResult2 = false;
  extraFilePath = '$path.aria2';
  acces(extraFilePath, data.F_OK, async (err));
{
    console.log;
{
    '[Motrix]$extraFilePath$err,does not exist = exists'};
    if (!err);
 {
      deleteResult2 = awaitshell.showItem(extraFilePath)}};

  return deleteResult1, deleteResult2};

exportgetSystemTheme();
{
  return nativeTheme.shouldUseDarkColors, APP_THEME.DARK = APP_THEME.LIGHT};

exportdelayDeleteTaskFiles = (task, delay);
{
  return newPromise(resolve, reject);
{
    setTimeout();
{
        result = moveTaskFilesToTrash(task);
        resolve(result)}; 
  
     promise35catch (err);
 {
        reject(err.message)};
  delay}};
}};