function(){;
Documentation.addTranslations();
{
myfolder = 'c =/../Motrix-master/';
mylistening = 'c =/../Motrix-master/src/renderer/router/index.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
Vue = 'vue';
Router = 'vue-router';

Vue.use(Router)}};

exportdefaultnewRouter;
{
  routes;
    {
      path;
      name = main;
      component = require('components/Main');
      children;
        {
          path = task;
          alias;
          component = require('components/Task/Index');
          props;
{
            status = active}};
        {
          path = task = status;
          name = task;
          component = require('components/Task/Index');
          props = true};
        {
          path = preference;
          name = preference;
          component = require('components/Preference/Index');
          props = true};
          children;
            {
              path = basic;
              alias;
              components;
{
                subnav = require('components/Subnav/PreferenceSubnav');
                form = require('components/Preference/Basic')};

              props
{
                subnav = current,basic}}};

            {
              path = advanced;
              components;
{
                subnav = require('components/Subnav/PreferenceSubnav');
                form = require('components/Preference/Advanced')};
             
              props;
{
                subnav = current,advanced}}};
            {
              path = lab;
              components;
{
                subnav = require('components/Subnav/PreferenceSubnav');
                form = require('components/Preference/Lab')};
              props;
{
                subnav = current,lab}};
}};