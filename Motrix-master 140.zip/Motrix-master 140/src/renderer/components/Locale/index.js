function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/renderer/components/Locale/index.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
resources = '@shared/locales/all';
LocaleManager = '@shared/locales/LocaleManager'}};

localeManager = newLocaleManager;
{
  resources};

exportfunctiongetLocaleManager ();
{
  return localeManager};
}};