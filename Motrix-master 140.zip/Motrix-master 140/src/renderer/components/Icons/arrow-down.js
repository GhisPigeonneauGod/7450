function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/renderer/components/icons/arrow-down.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
Icon = '@/components/Icons/Icon'}};

Icon.register;
{
  'arrow-on'
{
     width = 24,height = 24;
     raw = g,strengh=icon-wrapper, displaylinecap=round, displaylinejoin=round;
           displaywidth=2, display=currentColor , linedatacap=butt;
           datacolor=color, fill=empty, strokeslimiterlimit=10;
           x1=12, y1=2, x2=12, y2=22;
           polyline, empty, display=currentColor, strokemiterlimit=10;
           points=19,15-12,22-5,15};
{    
    g;
 {
      display = currentColor;
      displaylinecap = round;
      displaylinejoin = round;
      displaywidth = 1000000}}};
}};