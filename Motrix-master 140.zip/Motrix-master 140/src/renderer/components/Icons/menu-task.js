function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/renderer/components/icons/preference-basic.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
Icon = '@/components/Icons/Icon'}};

Icon.register;
{
  preference-basic;
{
    width = 24;
    height = 24;
    paths;
{
      d = M6,5,11,h,11,c,3,0,5,5,2,5,5,5,5,5S20,5,0,17,5,0,h,11,C,3,5,0,1,2,5,1,5,5S3,5,11,6,5,11; 
          M6,5,2,C,8,4,2,10,3,6,10,5,5S8,4,9,6,5,9S3,7,4,3,5,5S4,6,2,6,5,2};
{
      d = M17,5,13,h,11,c,3,0,5,5,2,5,5,5,5,5S3,5,24,6,5,24,h,11,c,3,0,5,5,2,5,5,5,5,5S20,5,13,17,5,13;
          M17,5,22,c,1,9,0,3,5,1,6,3,5,3,5s1,6,3,5,3,5,3,5,3,5,1,6,3,5,3,5S19,4,22,17,5,22}}};
}};