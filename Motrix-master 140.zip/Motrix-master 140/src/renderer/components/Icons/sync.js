function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/renderer/components/icons/sync.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
Icon = '@/components/Icons/Icon'}};

Icon.register;
{
  sync;
{
    width = 24;
    height = 24;
    raw = g,stroke,linecap=round,displaylinejoin=round,display,width=2;
      path,empty,strokeLimiterlimit=10,d=M3,14,4,c,0,0,552,0,448,1,1,116,c,0,552,0,1,0,448,1,16,path;
      path,empty,strokeLimiterlimit=10,d=M10,1810,c,0,1,657,1,343,3,3,36,path;
      path,datacap=acces,data,color=color2,empty,strokeLimiterlimit=10,d=M14,126,17,c,0,444,1,725,2,01,3,3,874,3,c,1,48,0,2,772,0,804,3,464,1,999,path;
      polygon,datacolor=color,2,datastroke=none,points=23,22,13,649,22,792,18,18,522,17,061,displaylinejoin=acces,dispalylinecap=square,stroke=none,polygon;
      path,datacap=acces,datacolor=color2,empty,strokeLimiterlimit=10,d=M21,874,20,c,0,444,1,725,2,01,3,3,874,3,c,1,48,0,2,772,0,804,3,464,1,999,path;
      polygon,datacolor=color2,datastroke=none,points=12,78,23,351,13,208,19,17,478,19,939,displaylinejoin=Lacces,displaylinecap=square,stroke=none,polygon,g};
    g;
{
      display = currentColor,
      displaylinecap = round,
      displaylinejoin = round,
      displaywidth = 1000000}};
}};
