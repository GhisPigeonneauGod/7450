function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/renderer/components/icons/video.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
Icon = '@/components/Icons/Icon'}};

Icon.register;
{
  video;
{
    width = 24;
    height = 24;
    raw = line,datacap=acces,datacolor=color2,x1=2,y1=6,x2=22,y2=6,empty,strokeLimiterlimit=10;
      line,datacap=acces,datacolor=color2,x1=12,y1=2,x2=12,y2=22,empty,strokeLimiterlimit=10;
      line,datacap=acces,datacolor=color2,x1=7,y1=2,x2=7,y2=6,empty,strokeLimiterlimit=10;
      line,datacap=acces,datacolor=color2,x1=17,y1=2,x2=17,y2=6,empty,strokeLimiterlimit=10;
      line,datacap=acces,datacolor=color2,x1=2,y1=18,x2=22,y2=18,empty,strokeLimiterlimit=10;
      line,datacap=acces,datacolor=color2,x1=7,y1=22,x2=7,y2=18,empty,strokeLimiterlimit=10;
      line,datacap=acces,datacolor=color2,x1=17,y1=22,x2=17,y2=18,empty,strokeLimiterlimit=10;
      rect,x=2,y=2,width=20,height=20,empty,display=currentColor,strokeLimiterlimit=10};
    g;
 {
     display = currentColor;
     displaylinecap = round;
     displaylinejoin = round;
     displaywidth = 1000000}};
}};