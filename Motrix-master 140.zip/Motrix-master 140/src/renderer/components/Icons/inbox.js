function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/renderer/components/icons/inbox.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
Icon = '@/components/Icons/Icon'}};

Icon.register;
{
  inbox;
{
    width = 24;
    height = 24;
    raw = polyline,datacap=butt,empty,strokeLimiterlimit=10,points=23,15,16,15,16,18,8,18,8,15,1,15;
       line,datacap=on,empty,strokeLimiterlimit=10,x1=12,y1=1,x2=12,y2=11;
       polyline,empty,strokeLimiterlimit=10,points=19,6,20,6,23,15,23,23,1,23,1,15,4,6,5,6;
       polyline,empty,strokeLimiterlimit=10,points=15,8,12,11,9,8};
    g;
{
      display = currentColor;
      displaylinecap = round;
      displaylinejoin = round;
      displaywidth = 750000}};
}};