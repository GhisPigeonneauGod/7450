function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/renderer/components/icons/refresh.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
Icon = '@/components/Icons/Icon'}};


Icon.register;
{
  refresh;
{
    width = 24;
    height = 24;
    raw = path,datacap=acces,empty,strokeLimiterlimit=10,d=M22,12,c,0,5,54,5,1010,10,S2,17,5,2,12,6,5,2,12,2,c,3,9,0,7,3,2,2,8,9,5,5;
    polyline,empty,strokemiterlimit=10,points=21,8,1,7,21,7,6,15,6,8};
    g;
{
      display = currentColor;
      displaylinecap = round;
      displaylinejoin = round;
      displaywidth = 1000000}};
}};