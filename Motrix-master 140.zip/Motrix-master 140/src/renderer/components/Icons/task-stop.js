function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/renderer/components/icons/task-stop.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
Icon = '@/components/Icons/Icon'}};

Icon.register;
{
  task-stop;
{
    width = 24;
    height = 24;
    paths;
{
      d = M22,1,2,C,1,447,1,1,1,447,1,2,20,c,0,0,553,0,447,1,1,1,20,c,0,553,0,1,0,447,1,1,2,C,23,1,447,22,553,1,22,1}}};
}};
