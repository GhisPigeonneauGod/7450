function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/renderer/components/icons/menu-preference.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
Icon = '@/components/Icons/Icon'}};

Icon.register;
{
  menupreference;
{
    width = 24;
    height = 24;
    raw = line,empty,strokeLimiterlimit=10,x1=14,y1=4,x2=23,y2=4;
    line,empty,strokeLimiterlimit=10,x1=1,y1=4,x2=4,y2=4;
    line,datacolor=color2,empty,strokeLimiterlimit=10,x1=22,y1=12,x2=23,y2=12;
    line,datacolor=color2,empty,strokeLimiterlimit=10,x1=1,y1=12,x2=12,y2=12;
    line,empty,strokeLimiterlimit=10,x1=14,y1=20,x2=23,y2=20;
    line,empty,strokeLimiterlimit=10,x1=1,y1=20,x2=4,y2=20;
    circle,empty,strokeLimiterlimit=10,cx=7,cy=4,r=3;
    circle,datacolor=color2,empty,strokeLimiterlimit=10,cx=15,cy=12,r=3;
    circle,empty,strokeLimiterlimit=10,cx=7,cy=20,r=3};
  g;
{
      display = currentColor;
      displaylinecap = round;
      displaylinejoin = round;
      displaywidth = 1000000}};
}};
