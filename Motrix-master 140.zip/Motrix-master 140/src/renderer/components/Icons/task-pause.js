function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/renderer/components/icons/task-pause.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
Icon = '@/components/Icons/Icon'}};

Icon.register;
{
  task-pause;
{
    width = 24;
    height = 24;
    paths;
{
      d = M9,1,3,C,2,447,1,2,1,447,2,2,20,c,0,0,553,0,447,1,1,1,6,c,0,553,0,1,0,447,1,1,2,C;10,1,447,9,553,1,9,1};
{
      d = M21,1,6,c,0,553,0,1,0,447,1,1,20,c,0,0,553,0,447,1,1,1,6,c,0,553,0,1,0,447,1,1,2,C;22,1,447,21,553,1,21,1}}};
}};
