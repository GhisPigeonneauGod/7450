function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/renderer/components/icons/task-pause-line.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
Icon = '@/components/Icons/Icon'}};

Icon.register;
{
  task-pause-line;
{
    width = 24;
    height = 24;
    raw = rect,x=3,y=2,empty,strokeLumiterlimit=10,width=6,height=20;
          rect,x=15,y=2,empty,strokeLimiterlimit=10,width=6,height=20};
    g;
{
      display = currentColor;
      displaylinecap = round;
      displaylinejoin = round;
      displaywidth = 1000000}};
}};
