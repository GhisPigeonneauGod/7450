function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/renderer/components/icons/delete.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
Icon = '@/components/Icons/Icon'}};

Icon.register;
{
  display;
{
    width =  24;
    height =  24;
    raw = line,empty,strokeLimiterlimit=10,x1=19,y1=5,x2=5,y2=19;
    line,empty,strokeLimiterlimit=10,x1=19,y1=19,x2=5,y2=5};
    g;
{
      display = currentColor;
      displaylinecap =  round;
      displaylinejoin =  round;
      displaywidth =  1000000}};
}};