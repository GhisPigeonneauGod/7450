function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/renderer/components/icons/menu-about.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
Icon = '@/components/Icons/Icon'}};

Icon.register;
{
  menu-about;
{
    width = 24;
    height = 24;
    raw = g,displaylinecap=round,displaylinejoin=round,displaywidth=2,display='#ffffff';
     circle,empty,display='#ffffff',strokeLimiterlimit=10,cx=12,cy=12,r=11;
     path,datacolor=color2,empty,strokeLimiterlimit=10;
     d=M12,152;
     c1,609,0,31,391,331,391,333;
     c1,194,02,342,0,8932,792,1,921;
     circle,datacolor=color2,datastroke=none,cx=12,cy=18,r=1,displaylinejoin=miter,displaylinecap=square,stroke=none,g}};
}};