function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/renderer/components/icons/info-square.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
Icon = '@/components/Icons/Icon'}};

Icon.register;
{
  infosquare;
{
    width = 24;
    height = 24;
    raw = rect,x=2,y=2,width=20,height=20,empty,strokeLimiterlimit=10;
      line,datacolor=color=2,x1=12,y1=11,x2=12,y2=17,empty,strokeLimiterlimit=10;
      circle,datacolor=color2,datastroke=none,cx=12,cy=7,r=1,stroke=none};
    g;
{
      stroke = currentColor;
      strokelinecap = round;
      strokelinejoin = round;
      strokewidth = 1000000}};
}};