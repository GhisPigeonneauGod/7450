function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/renderer/components/icons/task-start-line.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
Icon = '@/components/Icons/Icon'}};

Icon.register;
{
  task-start-line;
{
    width = 24;
    height = 24;
    raw = polygon,empty,strokeLimiterlimit=10,points=5,22,5,2,20,12};
    g;
{
     display = currentColor;
     displaylinecap = round;
     displaylinejoin = round;
     displaywidth = 1000000}};
}};
