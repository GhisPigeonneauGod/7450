function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/renderer/components/icons/preference-advanced.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
Icon = '@/components/Icons/Icon'}};

Icon.register;
{
  preference-advanced
{
    width = 24;
    height = 24;
    polygons,points = 10,853,9,439,6,707,5,293,8,4,4,0,0,4,4,8,5,293,6,707,9,189,10,603};
    paths;
{
      d = M18,94,13,9418,631,13,976,18,318,14,18,14,c,0,305,0,0,608,0,018,0,912,0,0531,3,641,4,499; 
            14,518,4,518,c,1,381,1,381,3,619,1,381,5,0,c,1,381,1,381,1,381,3,619,0,5118,94,13,94};
{
      d = M20,271,6,7711,3,042,3,04213,208,3,208,C,19,692,0,189,18,869,0,18,0,c,3,314,0,6,2,686,6,6; 
      c,0,0,594,0,089,1,166,0,25,1,7081,10,789,8,73,c,0,891,0,787,1,423,1,919,1,459,3,106,c,0,037,1,188,0,424,2,351,1,264,3,19; 
      C,2,082,23,551,3,167,24,4,321,24,c,1,239,0,2,421,0,532,3,241,1,46118,73,10,789,C,16,834,11,911,17,406,12,18,12,c,3,314,0,6,2,686,6,6,c,0,0,869,0,189,1,692,0,521,2,438120,271,6,771}};
}};