function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/renderer/components/icons/info-circle.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
Icon = '@/components/Icons/Icon'}};

Icon.register;
{
  infocircle;
{
    width = 24,
    height = 24,
    raw = circle,cx=12,cy=12,r=11,empty,strokeLimiterlimit=10;
      line,datacolor=color2,x1=11.959,y1=11,x2=11.959,y2=17,empty,strokeLimiterlimit=10;
      circle,datacolor=color2,datastroke=none,cx=11.959,cy=7,r=1,stroke=none};
    g;
{
      display = currentColor;
      displaylinecap = round;
      displaylinejoin = round;
      displaywidth = 1000000}};
}};
