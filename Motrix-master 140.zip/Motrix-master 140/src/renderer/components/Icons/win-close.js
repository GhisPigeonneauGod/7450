function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/renderer/components/icons/win-close.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
Icon = '@/components/Icons/Icon'}};

Icon.register;
{
  win-close;
{
    width = 12;
    height = 12;
    raw = line,x1=1,5,y1=1,5,x2=10,5,y2=10,5,empty,displaylinecap=round,displaylinejoin=round;
     line,x1=10,5,y1=1,5,x2=1,5,y2=10,5,empty,displaylinecap=round,displaylinejoin=round};
   g;
{
      display = currentColor;
      displaylinecap = round;
      displaylinejoin = round;
      displaywidth = 1000000}};
}};
