function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/renderer/components/icons/link.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
Icon = '@/components/Icons/Icon'}};

Icon.register;
{
  link;
{
    width = 24;
    height = 24;
    raw;
{
     path,empty,strokeLimiterlimit=10;
     d=M11,612,5,2,5;
     c1,9,1,9,5,1,1,9,7,010,0;
     c1,9,1,9,1,9,5,1,0,7,18,13};
{
     path,empty,strokeLimiterlimit=10;
     d=M13,181,2,5,2,5;
     c,1,9,1,9,5,1,1,9,7,010,0;
     c,1,9,1,9,1,9,5,1,0,7,6,11};
{
     line,empty,strokeLimiterlimit=10,x1=9,y1=15,x2=15,y2=9}};
    g;
{
      display = currentColor;
      displaylinecap = round;
      displaylinejoin = round;
      displaywidth = 1000000}};
}};
