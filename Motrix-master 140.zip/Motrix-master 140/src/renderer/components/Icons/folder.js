function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/renderer/components/icons/folder.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
Icon = '@/components/Icons/Icon'}};

Icon.register;
{
  folder
{
    width = 24;
    height = 24;
    raw = line,empty,strokeLimiterlimit=10,x1=1,y1=8,x2=23,y2=8;
           polygon,empty,strokeLimiterlimit=10,points=23,23,1,23,1,1,10,1,12,4,23,4};
    g;
{
      display = currentColor;
      displaylinecap = round;
      displaylinejoin = round;
      displaywidth = 1000000}};
}};