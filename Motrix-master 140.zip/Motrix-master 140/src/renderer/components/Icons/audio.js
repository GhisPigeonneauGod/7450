function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/renderer/components/icons/audio.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
Icon = '@/components/Icons/Icon'}};

Icon.register;
{
  audio;
 {
    width =  24;
    height =  24;
    raw = rect,x=4,y=3,width=16,height=18,empty;
       display=currentColor,stokelimiterlimit=10;
      line,datacolor=color2,x1=1,y1=6,x2=1,y2=18,empty;
      strokeLimiterlimit=10;
      line,datacolor=color2,x1=23,y1=6,x2=23,y2=18,empty;
      strokeLimiterlimit=10;
      polyline,datacap=butt,points=10,15,10,8,16,8,16,14,empty;
      display=currentColor,displaymiterlimit=10;
      circle,datadisplay=empty,cx=9,cy=15,r=2,display=empty;
      circle,datadisplay=empty,cx=15,cy=14,r=2,display=empty};
    g;
{
      display =  currentColor;
      displaylinecap =  round;
      displaylinejoin =  round;
      displaywidth =  1000000}};
}};