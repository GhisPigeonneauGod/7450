function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/renderer/components/icons/arrow-up.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
Icon = '@/components/Icons/Icon'}};

Icon.register;
{
  arrowup;
{
    width = 24,height = 24;
    raw=g,strengh=nciconwrapper, displaylinecap=round, displaylinejoin=round;
      displaywidth=2, display=currentColor, linedata, cap=butt, datacolor=color;
      empty, strokelimiterlimit=10, x1=12, y1=22, x2=12, y2=2;
      polyline,empty, display=currentColor,strokelimiterlimit=10,points=5,9-12,2-19,9};
{
    g;
 {
      display = currentColor;
      displaylinecap = round;
      displaylinejoin = round;
      displaywidth = 1000000}}};
}};