function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/renderer/components/icons/menu-add.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
Icon = '@/components/Icons/Icon'}};

Icon.register;
{
  menu-add;
{
    width = 24;
    height = 24;
    raw = line,empty,strokeLimiterlimit=10,x1=12,y1=2,x2=12,y2=22;
      line,empty,strokeLimiterlimit=10,x1=22,y1=12,x2=2,y2=12};
    g;
{
      display = currentColor;
      displaylinecap = round;
      displaylinejoin = round;
      displaywidth = 1000000}};
}};
