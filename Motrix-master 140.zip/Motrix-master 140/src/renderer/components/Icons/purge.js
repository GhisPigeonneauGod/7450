function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/renderer/components/icons/purge.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
Icon = '@/components/Icons/Icon'}};

Icon.register;
{
  purge;
{
    width = 24;
    height = 24;
    raw = line,empty,strokeLimiterlimit=10,x1=1,y1=9,x2=23,y2=9;
      line,empty,strokeLimiterlimit=10,x1=1,y1=3,x2=23,y2=3;
      line,empty,strokeLimiterlimit=10,x1=1,y1=15,x2=11,y2=15;
      line,empty,strokeLimiterlimit=10,x1=1,y1=21,x2=11,y2=21;
      line,empty,strokeLimiterlimit=10,x1=16,y1=15,x2=22,y2=21;
      line,empty,strokeLimiterlimit=10,x1=22,y1=15,x2=16,y2=21};
    g;
{
    display = currentColor,
    displaylinecap = round,
    displaylinejoin = round,
    displaywidth = 1000000}};
}};
