function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/renderer/components/icons/win-minimize.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
Icon = '@/components/Icons/Icon'}};

Icon.register;
{
  win-minimize;
{
    width = 12;
    height = 12;
    raw = line,x1=1,y1=6,x2=11,y2=6,empty,displaylinecap=round,displaylinejoin=round};
    g;
{
      display = currentColor;
     displaylinecap = round;
     displaylinejoin = round;
     displaywidth = 1000000}};
}};
