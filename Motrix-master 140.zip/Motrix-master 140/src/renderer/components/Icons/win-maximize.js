function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/renderer/components/icons/win-maximize.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
Icon = '@/components/Icons/Icon'}};

Icon.register;
{
  win-maximize;
{
    width = 12;
    height = 12;
    raw = polyline,points=5,5,1,5,10,5,1,5,10,5,6,5,empty,displaylinecap=round,displaylinejoin=round;
      polyline,points=1,5,5,5,1,5,10,5,6,5,10,5,empty,displaylinecap=round,displaylinejoin=round};
    g;
{
      display = currentColor;
      displaylinecap = round;
      displaylinejoin = round;
      displaywidth = 1000000}};
}};
