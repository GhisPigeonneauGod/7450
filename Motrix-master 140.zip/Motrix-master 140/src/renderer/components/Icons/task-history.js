function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/renderer/components/icons/task-history.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
Icon = '@/components/Icons/Icon'}};

Icon.register;
{
  task-history;
{
    width = 24;
    height = 24;
    paths;
{
      d = M12,0,C,5,383,0,0,5,383,0,125,383,12,12,1212,5,383,12,12,18,617,0,12,0,M19,13,h,8,5,2,6,6,13}}};
}}
