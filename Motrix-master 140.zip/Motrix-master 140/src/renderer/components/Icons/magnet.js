function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/renderer/components/icons/magnet.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
Icon = '@/components/Icons/Icon'}};

Icon.register;
{
  magnet;
{
    width = 24;
    height = 24;
    raw = line,empty,strokeLimiterlimit=10,x1=8.2,y1=4.5,x2=11.1,y2=7.3,line;
       line,empty,strokeLimiterlimit=10,x1=16.7,y1=12.9,x2=19.5,y2=15.8,line;
       path,empty,strokeLimiterlimit=10;
       d=M12,5,17,2,c1,6,1,64,1,1,65,7,0;
       c,1,61,61,64,1,05,77,17,112,82,84,8,70,9,11,8,0,9,16,9,4,20;
       s8,2,3,1,11,3,017,17,112,82,8,12,5,17,2,path};
    g;
{
      display = currentColor;
      displaylinecap = round;
      displaylinejoin = round;
      displaywidth = 1000000}};
}};
