function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/main/ui/TrayManager.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
CommandManager =  '..//components/CommandManager/'}};

exportargcommands = new CommandManager();
}};
