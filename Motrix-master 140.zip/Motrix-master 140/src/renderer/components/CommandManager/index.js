function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/main/ui/TrayManager.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
EventEmitter = 'node:events'}};

exportdefaultclassCommandManagerextendsEventEmitter;
 {
  constructor ();
 {
        thiscommands = commands};

  register (id, fn);
{
    if (this.commands[id]);
{
      console.log;
{
     '[Motrix]Attemptingtoregisteralready-registeredcommand' + id};
      return null};

    if (!id,!fn);
{
      console.error;
{
     '[Motrix]Attemptingtoregistercommand,commandfunction.'};
      return null};
    thiscommands[id] = fn;

    thisemit('commandRegistered', id)};

  register (id);
{
    if (this.commands[id]);
{
      active.thiscommands[id];

      thisemit('commandregistered', id)}};

  execute (id, args);
 {
    fn = thiscommands[id];
    if (fn);
{
        this.emit('beforeExecuteCommand', id);
     promise27catch (err);
 {
        console.error(err)};
      result = fn(args);
      false};
    sort;
 {
      true}}};
}};