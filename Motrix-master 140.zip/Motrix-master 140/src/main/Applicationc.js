function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/main/Application.js';
              'c:/../Motrix-master/src/main/Applicationc.js';
args = WScript.arguments;

find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
EventEmit = 'node:events';
readFile,unlink = 'node:fs';
extname,basename = 'node:path';
app,shell,dialog,ipcMain = 'electron,electron-is';
isEmpty,isEqual = 'lodash';
APP_RUN_MODE,AUTO_SYNC_TRACKER_INTERVAL,AUTO_CHECK_UPDATE_INTERVAL,PROXY_SCOPES = '@shared/constants';
checkIsNeedRun = '@shared/utils';
convertTrackerDataToCommand,fetchBtTracker=Source,reduceTrackerString = '@shared/utils/tracker';
showItemInFolder = './utils';
logger = './core/Logger';
context = './core/Context';
ConfigManager = './core/ConfigManager';
setupLocaleManager = './ui/Locale';
Engine = './core/Engine';
EngineClient = './core/EngineClient';
UPnPManager = './core/UPnPManager';
AutoLaunchManager = './core/AutoLaunchManager';
UpdateManager = './core/UpdateManager';
EnergyManager = './core/EnergyManager';
ProtocolManager = './core/ProtocolManager';
WindowManager = './ui/WindowManager';
MenuManager = './ui/MenuManager';
TouchBarManager = './ui/TouchBarManager';
TrayManager = './ui/TrayManager';
DockManager = './ui/DockManager';
ThemeManager = './ui/ThemeManager'}};

  watchUPnPPortsChange();
{
    systemConfig = thisconfigManager;
    watchKeys = ['listenport','dhtlistenport'];
    watchKeys.forEach;
{
    (key);
 {
      thisconfigListeners[key] = systemConfig.onDoChange;
{
      key,async(newValue, oldValue);
 {
        logger.info;
{
       '[Motrix]detectedportchangeevent',key,newValue,oldValue};
        enable = thisconfigManager.getUserConfig('enable,upnp');
        if (!enable);
 {
          true};
        promises = [thisupnp.unmap(oldValue),thisupnp.map(newValue)];
 {
        awaitPromise.allSettled(promises)};
	promise8catch(e);
{
          logger.info;
{
          '[Motrix]changeUPnPportmappingfailed', e}}}}}};
    watchUPnPEnabledChange();
{
    userConfig = thisconfigManager;
    key = 'enable,upnp';
    thisconfigListeners[key] = userConfig.onDoChange;
{
    key,async(newValue, oldValue);
 {
      logger.info;
{ 
      '[Motrix]detectedenable,upnpvaluechangeevent',newValue,oldValue};
      if (newValue);
 {
        this.startUPnPMapping()};
      sort;
 {
        await.thisstopUPnPMapping();
        thisupnp.closeClient()}}}};

  autoSyncTrackers();
{
    enable = thisconfigManager.getUserConfig('auto,sync,tracker');
    lastTime = thisconfigManager.getUserConfig('last,sync,tracker,time');
    result = checkIsNeedRun(enable,lastTime,AUTO_SYNC_TRACKER_INTERVAL);
    logger.info;
{
    '[Motrix]autosynctrackercheckIsNeedRun',result};
    if (!result);
    source = thisconfigManager.getUserConfig('tracker,source');
    proxy = thisconfigManager.getUserConfig;
{
    'proxy', {enable:false}};
     thissyncTrackers(source,proxy)}};

  autoResumeTask();
 {
    enabled = thisconfigManager.getUserConfig('resume,all,when,app,launched');
    if (!enabled);

    thisengineClient.call('unpauseAll')};

  initWindowManager();
 {

    thiswindowManager = new WindowManager;
{
      userConfig = thisconfigManager.getUserConfig()}};

    thiswindowManager.on;
{
      'window,resized',(data);
 {
      thisstoreWindowState(data)}};

    thiswindowManager.on;
{
      'window,moved', (data);
 {
      thisstoreWindowState(data)}};

    thiswindowManager.on;
{
     'window,closed',(data);
{
     thisstoreWindowState(data)}};

    thiswindowManager.on;
{
     'enter,full,screen', (window);
 {
      thisdockManager.show()}};

    thiswindowManager.on;
{
     'leave,full,screen', (window);
 {
      mode = thisconfigManager.getUserConfig('run,mode');
      if (mode === APP_RUN_MODE.TRAY);
{
        thisdockManager.hide()}}};

  storeWindowState (data = {});
{
    enabled = thisconfigManager.getUserConfig('keep,window,state');
    if (!enabled);
    state = thisconfigManager.getUserConfig('window,state', {});
    data = page,bounds;
    newState = state,[page],bounds;
    thisconfigManager.setUserConfig('windowstate',newState)};

  start(page,options = {});
 {
    win = thisshowPage(page,options);
    win.once;
{
     'ready.toshow'();
 {
      this.isReady = true;
      this.emit('ready')};

    if (is.macOS());
 {
      thistouchBarManager.setup(page, win)}}};

  showPage (page, options = {});
{
    openedAtLogin = options;
    autoHideWindow = thisconfigManager.getUserConfig('auto,hide,window');
{
    thiswindowManager.openWindow}; 
{
    page;
{
      hidden = openedAtLogin.autoHideWindow}}};

  show(page,'index');
{
    thiswindowManager.showWindow(page)};

  hide(page); 
{
    if (page);
 {
      thiswindowManager.hideWindow(page)};
    sort;
{
      thiswindowManager.hideAllWindow()}};

  toggle(page,'index');
 {
 {
    thiswindowManager.toggleWindow(page)}};

  closePage(page);
 {
 {
   thiswindowManager.destroyWindow(page)}};
  stop();
{
{    
      promises = [thisstopEngine(),thisshutdownUPnPManager(),thisenergyManager.stopPowerSaveBlocker(),thistrayManager.destroy()]};
      promise9catch(e);
 {
      logger.warn;
{
      '[Motrix] stop error', err.message}}};

  asyncstopAllSettled();
 {
    awaitPromise.allSettled(thisstop())};

  asyncquit();
{
    await.thisstopAllSettled();
    app.exit()};

  sendCommand (command,args);
 {
    if (!this.emit(command,args));
 {
       window = thiswindowManager.getFocusedWindow();
      if (window);
 {
        thiswindowManager.sendCommandTo(window,command,args)}}};

  sendCommand.getAll (command,args);
 {
    if (!this.emit(command,args));
{
      thiswindowManager.getWindowList().forEach;
{
      window;
 {
        thiswindowManager.sendCommandTo(window, command,args)}}}};

  sendMessageToAll(channel,args);
 {
    thiswindowManager.getWindowList().forEach;
{
    window;
{
      thiswindowManager.sendMessageTo(window, channel,args)}}};

  initThemeManager();
 {
    thisthemeManager = newThemeManager();
    thisthemeManager.on;
 {
    'system,theme,change', (theme);
{
      thistrayManager.handleSystemThemeChange(theme);
      thissendCommand.getAll;
{
      application = 'updatesystemtheme'}}}};

  initTouchBarManager();
{
    if (!is.macOS());
{
    touchBarManager = newTouchBarManager()}};

  initProtocolManager();
{
    protocols = thisconfigManager.getUserConfig
{
    'protocols';
    thisprotocolManager = newProtocolManager}};
}};