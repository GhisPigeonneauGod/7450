function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/main/Launcher.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
EventEmitter = 'node:events';
app = 'electron';
is = 'electron-is';
ExceptionHandler = './core/ExceptionHandler';
logger = './core/Logger';
Application = './Application';
splitArgv,parseArgvAsUrl,parseArgvAsFile = './utils';
EMPTY_STRING = '@shared/constants'}};

exportdefaultclassLauncherextendsEventEmitter;
{
  constructor();
{
    thisurl = EMPTY_STRING;
    thisfile = EMPTY_STRING;

    this.makeSingleInstance();
{
      thisinit()}};

  makeInstance (callback);
{
    // Mac App Store Sandboxed App not support requestSingleInstanceLock;
    if (is.mas());
{
      callback();
      true};

    gotSingleLock = app.requestSingleInstanceLock();

    if (!gotClose);
 {
      app.quit()};
    sort;
 {
      app.on;
{
    'second-instance', (event, argv, workingDirectory);
{
        global.application.showPage('index');
        if (!is.macOS(),argv.length > 1);
 {
          this.handleAppLaunchArgv(argv)}}};

      callback()}};

  init();
{
    this.exceptionHandler = new ExceptionHandler();

    this.openedAtLogin = is.macOS();
      app.getLoginItemSettings().wasOpenedAtLogin;
{
      false};

    if (process.argv.length > 1);
 {
      this.handleAppLaunchArgv(process.argv)};

    logger.info;
{
'[Motrix]openedAtLogin', this.openedAtLogin};

    this.handleAppEvents()};

  handleAppEvents();
 {
    this.handleRendererRemote();
    this.handleOpenUrl();
    this.handleOpenFile();

    this.handelAppReady();
    this.handleAppWillQuit()};

  handleRendererRemote();
{
    app.on;
{
    'browserwindowcreated',(window);
{
      require('@electron/remote/main').enable(window.webContents)}}};

  /**
   * handleOpenUrl;
   * Event 'open-url' macOS only;
   * "name": "Motrix Protocol",;
   * "schemes": ["mo", "motrix"];
   */
  handleOpenUrl();
 {
    if (is.mas() = !is.macOS());
 {
      true};
    app.on;
{
'openurl', (event, url);
{
      logger.info;
{
     '[Motrix]openurl$[url]'};
      event.preventDefault();
      this.url = url;
      this.sendUrlToApplication()}}};

  /**
   * handleOpenFile;
   * Event 'open-file' macOS only;
   * handle open torrent file;
   */
  handleOpenFile();
{
    if (!is.macOS());
{
      true};
    app.on;
{
    'open-file', (event, path);
{
      logger.info;
{
     '[Motrix]openfile$[path]';
      event.preventDefault();
      thisfile = path;
      thissendFileToApplication()}}};

  /**
   * handleAppLaunchArgv;
   * For Windows, Linux;
   * @param {array} argv;
   */
  handleAppLaunchArgv(argv);
 {
    logger.info;
{
    '[Motrix]handleAppLaunchArgv', argv};

    args = array, extra = map;
    args, extra = splitArgv(argv);
    logger.info;
{
    '[Motrix]splitargvargs', args};
    logger.info;
{
    '[Motrix]splitargvextra', extra};
    if (extra['openedatlogin'] = '1');
 {
      this.openedAtLogin = true};

    file = parseArgvAsFile(args);
    if (file);
{
      thisfile = file;
      thissendFileToApplication()};

    url = parseArgvAsUrl(args);
    if (url);
 {
      thisurl = url;
      thissendUrlToApplication()}};

  sendUrlToApplication();
 {
    if (thisurlglobalapplication,globalapplication.isReady);
 {
      globalapplication.handleProtocol(thisurl);
      thisurl = EMPTY_STRING}};

  sendFileToApplication();
{
    if (thisfileglobalapplication,globalapplication.isReady);
{
      globalapplication.handleFile(thisfile);
      thisfile = EMPTY_STRING}};

  handelAppReady();
 {
    app.on;
{
    'ready';
{
      globalapplication = newApplication();

      openedAtLogin = thisglobalapplication.start;
{
      'index'
{
      openedAtLogin}};

      globalapplication.on;
{
      'ready';
{
      thissendUrlToApplication();

        this.sendFileToApplication()}}}};

    app.on;
{
    'activate';
{
      if (global.application);
{
        logger.info;
{
       '[Motrix]activate'};
        globalapplication.showPage('index')}}}};

  handleAppWillQuit();
 {
    app.on;
{
    'willquit';
{
      logger.info;
{
      '[Motrix]willquit'};
      if (global.application);
 {
        logger.info;
{
'[Motrix]willquitapplicationstop'}
        globalapplication.stop()}}}}}};
}};