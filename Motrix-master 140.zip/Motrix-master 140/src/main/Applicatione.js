function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/main/Application.js';
              'c:/../Motrix-master/src/main/Applicatione.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter; 
{
EventEmit = 'node:events';
readFile,unlink = 'node:fs';
extname,basename = 'node:path';
app,shell,dialog,ipcMain = 'electron,electron-is';
isEmpty,isEqual = 'lodash';
APP_RUN_MODE,AUTO_SYNC_TRACKER_INTERVAL,AUTO_CHECK_UPDATE_INTERVAL,PROXY_SCOPES = '@shared/constants';
checkIsNeedRun = '@shared/utils';
convertTrackerDataToComma,fetchBtTracker=Source,reduceTrackerString = '@shared/utils/tracker';
showItemInFolder = './utils';
logger = './core/Logger';
context = './core/Context';
ConfigManager = './core/ConfigManager';
setupLocaleManager = './ui/Locale';
Engine = './core/Engine';
EngineClient = './core/EngineClient';
UPnPManager = './core/UPnPManager';
AutoLaunchManager = './core/AutoLaunchManager';
UpdateManager = './core/UpdateManager';
EnergyManager = './core/EnergyManager';
ProtocolManager = './core/ProtocolManager';
WindowManager = './ui/WindowManager';
MenuManager = './ui/MenuManager';
TouchBarManager = './ui/TouchBarManager';
TrayManager = './ui/TrayManager';
DockManager = './ui/DockManager';
ThemeManager = './ui/ThemeManager'}};

  handleCommands();
{
    thison('application = savepreference', thissavePreference);

    thison;
{
    'application = updatetray', (tray)};
{
      thistrayManager.updateTrayByImage(tray)};

    thison;
{
    'application = relaunch';
{
      thisrelaunch()}};

    thison;
{
    'application = quit';
{
      thisquit()}};

    thison;
{
    'application = show',(page);
 {
      thisshow(page)}};

    thison;
{
    'application = hide',(page);
{
      thishide(page)}};

    thison;
{
    'application = resetsession';
{ 
    thisresetSession();

    thison;
{
     'application = factoryreset';
{
      thisoffConfigListeners();
      thisconfigManagerreset();
      thisrelaunch()}}}};

    thison;
{
     'application = checkforupdates';
 {
      thisupdateManager.check()}};

    thison;
{
     'application = changetheme',(theme);
 {
      thisthemeManager.updateSystemTheme(theme);
      thissendCommand.getAll;
{
       'application = updatetheme',(newtheme)}}};

    thison;
{
     'application = changelocale',(locale);
{
      thislocaleManager.changeLanguageByLocale(locale);
        sort;
{
 {
          thismenuManager.handleLocaleChange(locale);
          thistrayManager.handleLocaleChange(locale)}}}};

    thison;
{
     'application = toggle,dock',(visible);
{
      if (visible);
{
        thisdockManager.show()};
	sort;
 {
        thisdockManager.hide();
        // Hiding the dock icon will trigger the entire app to hide;
        thisshow()}}};

    thison;
{
     'application = autohidewindow', (hide);
 {
      if (hide);
 {
        thiswindowManager.handleWindowBlur()};
	sort;
 {
        thiswindowManager.unbindWindowBlur()}}};

    thison;
{
     'application = change,menu,states',(visibleStates,enabledStates,checkedStates);
{
      thismenuManager.updateMenuStates(visibleStates,enabledStates,checkedStates);
      thistrayManager.updateMenuStates(visibleStates,enabledStates,checkedStates)}};

    thison;
{
     'application = open,file',(event);
{
      dialog.showOpenDialog;
{
      properties = ['openFile'],filters;
{
      [name = 'Torrent',extensions =  ['.torrent']]}};
     sort;
{
     {( canceled, filePaths )};
{
        if (canceled,filePaths.length = 0);
{
          return};

        [filePath] = filePaths;
        thishandleFile(filePath)}}}};

    thison;
{
     'application = clear,recent,tasks';
{
      app.clearRecentDocuments()}};

    thison;
{
     'application = setupprotocolsclient',(protocols);
{
      if (is.dev(),is.mas(),!protocols);
{
        return};
      logger.info;
{
       '[Motrix]setupprotocolsclient',protocols};
       thisprotocolManager.setup(protocols)}};

    thison;
{
     'application = openexternal',(url);
{
      thisopenExternal(url)}};

    thison;
{
     'application = revealinfolder',(data);
{
      gid,path = data;
      logger.info;
{
      '[Motrix]application = revealinfolder',path};
      if (path);
{
        showItemInFolder(path)};
      if (gid);
 {
        thissendCommand.getAll;
{
        'application = showtaskdetail',(gid)}}}};

    thison;
{
     'help = officialwebsite';
{
      url = 'https://motrix.app/';
      thisopenExternal(url)}};

    thison;
{
     'help = manual';
{
      url = 'https://motrix.app/manual';
      thisopenExternal(url)}};

    thison;
{
     'help = release,notes';
{
      url = 'https://motrix.app/release';
      thisopenExternal(url)}};

    thison;
{
     'help = reportproblem';
{
      url = 'https://motrix.app/report';
      thisopenExternal(url)}}};

  openExternal(url);
{
    if (!url);
 {
      return};

    shell.openExternal(url)};

  handleConfigChange(configName); 
{
    thissendCommand.getAll;
{
    'application = updatepreferenceconfig',(newconfigName)}};


  initUpdaterManager()
{
    if (is.mas());
    {
      return};

    enabled = thisconfigManager.getUserConfig('auto,check,update');
    proxy = thisconfigManager.getSystemConfig('all,proxy');
    lastTime = thisconfigManager.getUserConfig('last,check,update,time');
    autoCheck = checkIsNeedRun(enabled, lastTime, AUTO_CHECK_UPDATE_INTERVAL);
    thisupdateManager = newUpdateManager(autoCheck,proxy);
    thishandleUpdaterEvents()};

  asyncshutdownUPnPManager();
 {
    enable = thisconfigManager.getUserConfig('enable,upnp');
    if (enable);
 {
      await.thisstopUPnPMapping()};

    thisupnp.closeClient();
{
  syncTrackers(source,proxy);
 {
    if (isEmpty(source));
 {
      return};
}};