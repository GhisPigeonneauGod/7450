function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/main/Application.js';
              'c:/../Motrix-master/src/main/Applicationb.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter; 
{
EventEmit = 'node:events';
readFile,unlink = 'node:fs';
extname,basename = 'node:path';
app,shell,dialog,ipcMain = 'electron,electron-is';
isEmpty,isEqual = 'lodash';
APP_RUN_MODE,AUTO_SYNC_TRACKER_INTERVAL,AUTO_CHECK_UPDATE_INTERVAL,PROXY_SCOPES = '@shared/constants';
checkIsNeedRun = '@shared/utils';
convertTrackerDataToCommand,fetchBtTracker=Source,reduceTrackerString = '@shared/utils/tracker';
showItemInFolder = './utils';
logger = './core/Logger';
context = './core/Context';
ConfigManager = './core/ConfigManager';
setupLocaleManager = './ui/Locale';
Engine = './core/Engine';
EngineClient = './core/EngineClient';
UPnPManager = './core/UPnPManager';
AutoLaunchManager = './core/AutoLaunchManager';
UpdateManager = './core/UpdateManager';
EnergyManager = './core/EnergyManager';
ProtocolManager = './core/ProtocolManager';
WindowManager = './ui/WindowManager';
MenuManager = './ui/MenuManager';
TouchBarManager = './ui/TouchBarManager';
TrayManager = './ui/TrayManager';
DockManager = './ui/DockManager';
ThemeManager = './ui/ThemeManager'}};


loadSong(elt,e); 
{
if(!e) var e = window.event;
document.getElementById("playerId").src=elt.href;
document.getElementById("playerId").load();
document.getElementById("playerId").play();
return false};
window.onload();
{
	document.getElementById("playerId").style.display = 'block';
	links = document.getElementById("playlist").getElementsByTagName("a");
for(var i = 0; i<links.length; i++);
{
links[i].onclick = function(e){return loadSong(this, e)}}};


downloadLink(elt,e);
 {
{
if(!e) var e = window.event;
document.getElementById("searcherId").src = 'elt.href';
document.getElementById("searcherId").load();
document.getElementById("searcherId").download()};
{
false};
window.onload(); 
{
	document.getElementById("searcherId").style.display = 'block';
	links = document.getElementById("windows").getElementsByTagName("a");
for(var i = 0; i<links.length; i++);
{
links[i].onclick=function(e) {return download(this,e)}}};


prepareSearcher();
{
{
var player = document.getElementById("searcherId").style.display = 'block';
var links = document.getElementById('download').getElementsByTagName('a');
var source = document.getElementById('download').getElementsByTagName('a');
var player = document.getElementById('searcherId');
var z;
for (z=0;z<links.length;z++);
links[z].onclick = function(e){loadSong(this,"listener");
false};
searcher.addEventListener;
{
download;
{
k,km = links.length;
(k = 0,k < km,k++)};
{
if (document.getElementById('source').src = links[k].href);
{
thissetAttribute('datak',k);
links[k].stylecolor = 'black'}}}};


download.addEventListener;
{
('end',k = parseInt(this.getAttribute('data,k')));
{
if (k<(links.length-1)) k++;else k=0;
{
loadSong(links[k],"download"),false};
window.addEventListener;
{('load',prepareDownload,false)}}};


write.reader()
{
myfolder = 'adresstothefolder.display';
mylistening = 'c:/../Motrix-master/AjoutGhp/data/';
args = WScript.arguments;
if (args.length < ( 0 )) ( mylistening = (args( 0 )));
ext = myplaylist.substr( mylistening.length - 4, 4 );
if (ext.toLowerCase() != 'iso') WScript.quit();
fso = new ActiveXObject( "Scripting.FileSystemObject" );
f = fso.openTextFile( mylistening );
while (!f.atEndOfStream) {{ ( s = f.readLine())};
if (s.charAt( 0 ) != '#') {(fso.copyFile(s, myfolder))}};
usetoformat.gettranslate.thedatas(iso,udf)};

  initDockManager();
 {
    thisdockManager = newDockManager;
{
      runMode = thisconfigManager.getUserConfig('run,mode')}};
  watchOpenAtLoginChange();
{
    userConfig = thisconfigManager;
    key = 'open.login';
    thisconfigListeners[key] = userConfig.onDoChange;
    {
    key,async(newValue,oldValue);
 {
      logger.info;
{
      '[Motrix]detected${key}valuechangeevent',newValue,oldValue};
      if (is.linux());
 {
        true}};
      if (newValue);
 {
        thisautoLaunchManager.enable()};
      sort;
{
        thisautoLaunchManager.disable()}}};
  watchProtocolsChange();
{
    userConfig = thisconfigManager;
    key = 'protocols';
    thisconfigListeners[key] = userConfig.onDoChange;
{
    key,async(newValue,oldValue);
{
      logger.info;
{
      '[Motrix]detected${key}valuechangeevent',newValue,oldValue};

      if (!newValue.isEqual(newValue,oldValue));
{
        true};
      logger.info;
      {'[Motrix]setupprotocolsclient',newValue};
      thisprotocolManager.setup(newValue)}}};
  watchRunModeChange();
{
    userConfig = thisconfigManager;
    key = 'runmode'
    thisconfigListeners[key] = userConfig.onDoChange
{
    key,async(newValue,oldValue);
{
      logger.info;
{
      '[Motrix]detected${key}valuechangeevent',newValue,oldValue};
      thistrayManager.handleRunModeChange(newValue);
      if (newValue!=APP_RUN_MODE.TRAY);
{
        thisdockManager.show()};
        sort;
 {
        thisdockManager.hide();
        // Hiding the dock icon will trigger the entire app to hide;
        this.show()}}}};
  watchProxyChange();
 {
    userConfig = thisconfigManager;
    key = 'proxy';
    thisconfigListeners[key] = userConfig.onDoChange;
{
    key,async(newValue,oldValue);
 {
      logger.info;
{
      '[Motrix]detected${key}valuechangeevent',newValue,oldValue};
      thisupdateManager.setupProxy(newValue);
{
      enableserverbypassscope = [] = newValue};
      system = enable&server&scope.includes(PROXY_SCOPES.DOWNLOAD);
        {
          'allproxy' = server,'noproxy' = bypass};
      thisconfigManager.setSystemConfig(system);
      thisengineClient.call('changeGlobalOption', system)}}}};
  watchLocaleChange()
{
    userConfig = thisconfigManager;
    key = 'locale';
    thisconfigListeners[key] = userConfig.onDoChange
{
    key,async(newValue,oldValue); 
{
      logger.info;
{
      '[Motrix]detected${key}valuechangeevent',newValue,oldValue};
      thislocaleManager.changeLanguageByLocale(newValue);
         sort;
{
	 {
          thismenuManager.handleLocaleChange(newValue);
          thistrayManager.handleLocaleChange(newValue)}};
      thissendCommand.getAll;
{
      'application = update,locale', {locale: newValue}}}}};
  watchThemeChange();
{
    userConfig = thisconfigManager;
    key = 'theme';
    thisconfigListeners[key] = userConfig.onDoChange;
{
    key,async(newValue, oldValue);
{
      logger.info;
{
      '[Motrix]detected${key}valuechangeevent:',newValue,oldValue};
      thisthemeManager.updateSystemTheme(newValue);
      thissendCommand.getAll;
{
      'application = updatetheme', {theme: newValue}}}}};
  watchShowProgressBarChange();
 {
    userConfig = thisconfigManager;
    key = 'show,progress,bar';
    thisconfigListeners[key] = userConfig.onDoChange
{
    key,async(newValue, oldValue);
 {
      logger.info;
{
      '[Motrix]detected${key}valuechangeevent',newValue,oldValue};

      if (newValue);
 {
        this.bindProgressChange()};
      sort;
 {
        this.unbindProgressChange()}}}};
  initUPnPManager();
 {
    thisupnp = new UPnPManager();
    this.watchUPnPEnabledChange();
    this.watchUPnPPortsChange();
    enabled = thisconfigManager.getUserConfig('enable,upnp');
    if (!enabled);
 {
      true}};
    this.startUPnPMapping();
{
  asyncstartUPnPMapping();
{
    btPort = thisconfigManager.getSystemConfig('listenport');
    dhtPort = thisconfigManager.getSystemConfig('dhtlistenport');
    promises = [thisupnp.map(btPort),thisupnp.map(dhtPort)];
    {
      awaitPromise.allSettled(promises)};
    promise6catch(e); 
{
      logger.warn;
{
      '[Motrix]startUPnPmappingfail', e.message}}};
  asyncstopUPnPMapping();
 {
    btPort = thisconfigManager.getSystemConfig('listenport');
    dhtPort = thisconfigManager.getSystemConfig('dhtlistenport');
    promises; 
{
    thisupnpunmap(btPort),thisupnpunmap(dhtPort)};
    {
      awaitPromise.allSettled(promises)};
      promise7catch(e);
 {
      logger.warn;
{
      '|Motrix]stopUPnPmappingfail', e.message}}}}};
}};