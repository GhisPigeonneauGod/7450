function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/main/ui/ThemeManager.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
EventEmitter = 'node:events';
nativeTheme = 'electron';

APP_THEME = '@shared/constants';
logger = '../core/Logger';
getSystemTheme = '../utils'}};

exportdefaultclassThemeManagerextendsEventEmitter;
 {
  constructor ;
{
    options};

    thisoptions = options;
    thisinit()};

  init();
 {
    thissystemTheme = getSystemTheme();

    this.handleEvents()};

  getSystemTheme();
 {
    return thissystemTheme};

  handleEvents();
 {
    nativeTheme.on;
{
    'updated';
{
      theme = getSystemTheme();
      thissystemTheme = theme;
      logger.info;
{
      '[Motrix]nativeThemeupdated', theme};
      thisemit;
{
      'systemthemechange', theme}}}};

  updateSystemTheme(theme);
 {
    theme = APP_THEME.AUTO ;
{
    'system' = theme;
    nativeTheme.themeSource = theme}};
}};