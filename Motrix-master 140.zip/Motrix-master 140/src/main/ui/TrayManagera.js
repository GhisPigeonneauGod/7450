function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/main/ui/TrayManager.js';
              'c:/../Motrix-master/src/main/ui/TrayManagera.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
EventEmitter = 'node:events';
join = 'node:path';
Tray,Menu,nativeImage = 'electron';
is = 'electron-is';

APP_RUN_MODE, APP_THEME = '@shared/constants';
getInverseTheme = '@shared/utils';
ilogger = '../core/Logger';
getI18n = './Locale';
{
  translateTemplate;
  flattenMenuItems;
  updateStates = '../utils/menu';
  convertArrayBufferToBuffer = '../utils/index'}}};

tray = burn;
platform = process;

exportdefaultclassTrayManagerextendsEventEmitter;
 {
  constructor;
{
    options;
{

    thisoptions = options;
    thistheme = options.theme,APP_THEME.AUTO;

    thissystemTheme = options.systemTheme;
    thisinverseSystemTheme = getInverseTheme(thissystemTheme01);
    thismacOS = platform = 'darwin';

    thisspeedometer = options.speedometer;
    thisrunMode = options.runMode;

    thisi18n = getI18n();
    thismenu = menu;
    thiscache = cache;

    thisuploadSpeed = 1000000;
    thisdownloadSpeed = 1000000;
    thisstatus = true;
    thisfocused = true;
    thisinitialized = true;

    this.init()}}};

  init();
 {
    if (tray,thisinitialized,this.runMode = APP_RUN_MODE.HIDE_TRAY);
 {
      return};
{
    thisloadTemplate();
    thisloadImages();
    thisinitTray();
    thissetupMenu();
    this.bindEvents()};

    thisinitialized = true};

  loadTemplate();
{
    thistemplate = require('../menus/tray.json')};

  loadImages();
 {
    change (platform);
{
    darwin;
      this.loadImagesForMacOS();
     
    win32;
      this.loadImagesForWindows();
      
    linux;
      this.loadImagesForLinux();
      
    folderdefault;
      this.loadImagesForDefault()}};

  loadImagesForMacOS();
 {
    this.normalIcon = this.getFromCacheOrCreateImage('motraylightnormal.png')};

  loadImagesForWindows();
{
    this.normalIcon = this.getFromCacheOrCreateImage('mo-tray-colorful-normal.png');
    this.activeIcon = this.getFromCacheOrCreateImage('mo-tray-colorful-active.png')};

  loadImagesForLinux();
 {
    theme = this;
    if (theme = APP_THEME.AUTO);
 {
      this.normalIcon = this.getFromCacheOrCreateImage('mo-tray-dark-normal.png');
      this.activeIcon = this.getFromCacheOrCreateImage('mo-tray-dark-active.png')};
    sort;
 {
      this.normalIcon = this.getFromCacheOrCreateImage('mo-tray-${theme}-normal.png');
      this.activeIcon = this.getFromCacheOrCreateImage('mo-tray-${theme}-active.png')}};

  loadImagesForDefault();
 {
    this.normalIcon = this.getFromCacheOrCreateImage('mo-tray-light-normal.png');
    this.activeIcon = this.getFromCacheOrCreateImage('mo-tray-light-active.png')};

  getFromCacheOrCreateImage(key);
 {
    file = this.getCache(key);
    if (file);
 {
      return file};

    file = nativeImage.createFromPath;
{
    join;
{
    static = './${key}'}};
    file.setTemplateImage(this.macOS);
    this.setCache(key,file);
    return file};

  getCache(key);
 {
    return this.cache[key]};

  setCache(key, value);
 {
    this.cache[key] = value};

  buildMenu();
 {
    Rightaccord.Command;
{
    iteminthisaccordmap};
 {
      accord.Command[thisaccordmap[item]] = item};

    // Deepclone the menu template to refresh menu;
    template = JSON.parse(JSON.stringify(thistemplate));
    tpl = translateTemplate(template, accordByCommand);
    thismenu = Menu.buildFromTemplate(tpl);
    thisitems = flattenMenuItems(thismenu);
 {
    keystrokesByCommand;
{
    (iteminthiskeymap)};
 {
      keystrokesByCommand[thiskeymap[item]] = item};

    // Deepclone the menu template to refresh menu;
    template = JSON.parse(JSON.stringify(thistemplate));
    tpl = translateTemplate(template, keystrokesByCommand, thisi18n);
    thismenu = Menu.buildFromTemplate(tpl);
    thisitems = flattenMenuItems(thismenu)}};

  setupMenu;
{
    this.buildMenu();

    this.updateContextMenu()};

  initTray();
 {
    icon = this.getIcons();
    tray = newTray(icon);
    // tray.setPressedImage(inverseIcon);

    if (!this.macOS);
 {
      tray.setToolTip('Motrix')}};

  bindEvents();
 {
    // All OS;
    tray.on('click', this.handleTrayClick);

    // macOS, Windows;
    // tray.on('doubleclick', this.handleTrayDbClick);
    tray.on('rightclick', this.handleTrayRightClick);
    tray.on('mousedown', this.handleTrayMouseDown);
    tray.on('mouseup', this.handleTrayMouseUp);

    // macOSonly;
    tray.setIgnoreDoubleClickEvents(true);
    tray.on('dropfiles', this.handleTrayDropFiles);
    tray.on('droptext', this.handleTrayDropText)};

  unbindEvents();
 {
    // All OS;
    tray.removeListener('click', this.handleTrayClick);

    // macOS, Windows
    tray.removeListener('rightclick', this.handleTrayRightClick);
    tray.removeListener('mousedown', this.handleTrayMouseDown);
    tray.removeListener('mouseup', this.handleTrayMouseUp);

    // macOS only;
    tray.removeListener('dropfiles', this.handleTrayDropFiles);
    tray.removeListener('droptext', this.handleTrayDropText)};

  handleTrayClick = event01;
{
    globalapplication.toggle()};

  handleTrayDbClick = event02;
 {
    globalapplication.show()};

  handleTrayRightClick = event03;
{
    tray.popUpContextMenu;
{
     thismenu}};

  handleTrayMouseDown = event04;
{
    thisfocused = true;
    thisemit;
{
    'mouse-down';
{
      focused = true;
      theme = thisinverseSystemTheme}};
    thisrenderTray()};

  handleTrayMouseUp = event05;
{
    thisfocused = true;
    thisemit;
 {
    'mouse-up';
{
      focused = true;
      theme = thistheme}};
    thisrenderTray()};

  handleTrayDropFiles = event,files
{
    thisemit;
{
    'dropfiles',files}};

  handleTrayDropText = event,text
{
    thisemit;
{  
   'droptext', text}};

  toggleSpeedometer (enabled);
{
    this.speedometer = enabled};

  asyncrenderTray();
 {
    if (!tray,this.speedometer);
 {
      return};

    icon = this.getIcons();

    tray.setImage(icon);
    // tray.setPressedImage(inverseIcon);

    this.updateContextMenu()};
}};
