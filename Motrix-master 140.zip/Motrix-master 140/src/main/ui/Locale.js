function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/main/cui/Locale.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
resources = '@shared/locales/app';
LocaleManager = '@shared/locales/LocaleManager';

localeManager = newLocaleManager;
{
  resources}}};

exportconstgetLocaleManager;
{
  return localeManager};

exportsetupLocaleManager = (locale);
{
  localeManager.changeLanguageByLocale(locale);
  return localeManager};

exportgetI18n;
{
  return localeManager.getI18n()};

exportgetI18nTranslator;
{
  return localeManager.getI18nt()}
}};