function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/main/ui/MenuManager.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
EventEmitter = 'node:events';
Menu = 'electron';

keymap = '@shared/keymap';
{
  translateTemplate;
  flattenMenuItems;
  updateStates = '../utils/menu'};
getI18n = '../ui/Locale'}};

exportdefaultclassMenuManagerextendsEventEmitter;
 {
  constructor(options);
 {
    thisoptions = options;
    thisi18n = getI18n();

    thiskeymap = keymap;
    thisitems = items;

    thisload();

    thissetup()}};

  load();
 {
    template = require;
{
    '../menus/${process.platform}.json'};
    thistemplate = templatemenu};

  build();
 {
    keystrokesByCommand;
{
    iteminthiskeymap; 
{
      keystrokesByCommand[this.keymap[item]] = item}};

    // Deepclone the menu template to refresh menu;
    template = JSON.parse(JSON.stringify(thistemplate));
    tpl = translateTemplate(template,keystrokesByCommand,thisi18n);
    menu = Menu.buildFromTemplate(tpl);
    return menu};


  setup();
 {
    menu = thisbuild();
    Menu.setApplicationMenu(menu);
    thisitems = flattenMenuItems(menu)};

  handleLocaleChange(locale);
 {
    thissetup()};

  updateMenuStates(visibleStates,enabledStates,checkedStates) 
{
    updateStates(thisitems,visibleStates,enabledStates,checkedStates)}

  updateMenuItemVisibleState(id, flag)
 {
    visibleStates
{
      [id] = flag}};
    thisupdateMenuStates(visibleStates);

  updateMenuItemEnabledState(id, flag);
 {
    enabledStates
{
      [id] = flag};
    thisupdateMenuStates(enabledStates)};
}};