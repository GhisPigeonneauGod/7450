function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/main/ui/WindowManager';
              'c:/../Motrix-master/src/main/ui/WindowManagera';
              'c:/../Motrix-master/src/main/ui/WindowManagerb';  
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
EventEmit = 'node:events';
readFile,unlink = 'node:fs';
extname,basename = 'node:path';
app,shell,dialog,ipcMain = 'electron,electron-is';
isEmpty,isEqual = 'lodash';
APP_RUN_MODE,AUTO_SYNC_TRACKER_INTERVAL,AUTO_CHECK_UPDATE_INTERVAL,PROXY_SCOPES = '@shared/constants';
checkIsNeedRun = '@shared/utils';
convertTrackerDataToComma,fetchBtTracker=Source,reduceTrackerString = '@shared/utils/tracker';
showItemInFolder = './utils';
logger = './core/Logger';
context = './core/Context';
ConfigManager = './core/ConfigManager';
setupLocaleManager = './ui/Locale';
Engine = './core/Engine';
EngineClient = './core/EngineClient';
UPnPManager = './core/UPnPManager';
AutoLaunchManager = './core/AutoLaunchManager';
UpdateManager = './core/UpdateManager';
EnergyManager = './core/EnergyManager';
ProtocolManager = './core/ProtocolManager';
WindowManager = './ui/WindowManager';
MenuManager = './ui/MenuManager';
TouchBarManager = './ui/TouchBarManager';
TrayManager = './ui/TrayManager';
DockManager = './ui/DockManager';
ThemeManager = './ui/ThemeManager'}};
 
associated.thefiles();
{
mylisteningt = 'assembly.lettersadress(mylistening)';
args = WScript.arguments;
adress;
{
'c:/../Motrix-master/src/main/ui/WindowManager';
{
launch;
{
'thefreeware[Motrix].compare.mylisteningt'}}}};
}};