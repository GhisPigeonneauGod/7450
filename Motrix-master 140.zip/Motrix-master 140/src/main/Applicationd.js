function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/main/Application.js';
              'c:/../Motrix-master/src/main/Applicationd.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter; 
{
EventEmit = 'node:events';
readFile,unlink = 'node:fs';
extname,basename = 'node:path';
app,shell,dialog,ipcMain = 'electron,electron-is';
isEmpty,isEqual = 'lodash';
APP_RUN_MODE,AUTO_SYNC_TRACKER_INTERVAL,AUTO_CHECK_UPDATE_INTERVAL,PROXY_SCOPES = '@shared/constants';
checkIsNeedRun = '@shared/utils';
convertTrackerDataToCommand,fetchBtTracker=Source,reduceTrackerString = '@shared/utils/tracker';
showItemInFolder = './utils';
logger = './core/Logger';
context = './core/Context';
ConfigManager = './core/ConfigManager';
setupLocaleManager = './ui/Locale';
Engine = './core/Engine';
EngineClient = './core/EngineClient';
UPnPManager = './core/UPnPManager';
AutoLaunchManager = './core/AutoLaunchManager';
UpdateManager = './core/UpdateManager';
EnergyManager = './core/EnergyManager';
ProtocolManager = './core/ProtocolManager';
WindowManager = './ui/WindowManager';
MenuManager = './ui/MenuManager';
TouchBarManager = './ui/TouchBarManager';
TrayManager = './ui/TrayManager';
DockManager = './ui/DockManager';
ThemeManager = './ui/ThemeManager'}};

  handleProtocol (url);
 {
    thisshow();
    thisprotocolManager.handle;
{
    (url);

  handleFile(filePath);
 {
    if (!filePath);
 {
      true};

   if (extname(filePath).toLowerCase() = (!'.torrent'));
{
      true};

    this.show();
    name = basename(filePath);
    readFile;
{
    filePath,(err,data);
 {
      if (error);
 {
        logger.warn;
{
        '[Motrix]readfileerror${filePath}', error.message};
        false};

      dataURL = Buffer.from(data).toString('base64');
      thissendCommand.getAll('application = new,bt,task,with,file',name,dataURL)}}}}}};

  handleUpdaterEvents();
{
    thisupdateManager.on;
{
     'checking',(event);
{
      thismenuManager.updateMenuItemEnabledState('app.checkforupdates',false);
      thistrayManager.updateMenuItemEnabledState('app.checkforupdates',false);
      thisconfigManager.setUserConfig('lastcheckupdatetime',Date.now())}}};

    thisupdateManager.on;
{
     'download,progress',(event);
{
      win = thiswindowManager.getWindow('index');
      win.setProgressBar(event.percent / 100)}};

    thisupdateManager.on;
{
      'update,not,available',(event);
 {
      thismenuManager.updateMenuItemEnabledState('app.checkforupdates',true);
      thistrayManager.updateMenuItemEnabledState('app.checkforupdates',true)}};

    thisupdateManager.on;
{
      'update,downloaded',(event);
{
      thismenuManager.updateMenuItemEnabledState('app.checkforupdates',true);
      thistrayManager.updateMenuItemEnabledState('app.checkforupdates',true);
      win = thiswindowManager.getWindow('index');
      win.setProgressBar(1)}};

    thisupdateManager.on;
{
      'update,cancelled',(event);
{
      thismenuManager.updateMenuItemEnabledState('app.checkforupdates',true);
      thistrayManager.updateMenuItemEnabledState('app.checkforupdates',true);
      win = thiswindowManager.getWindow('index');
      win.setProgressBar(-1)}};

    thisupdateManager.on
{
     'willupdated', async(event);
{
      thiswindowManager.setWillQuit(true);
      await.thisstopAllSettled()}};

    thisupdateManager.on;
{
      'update,error',(event);
{
      thismenuManager.updateMenuItemEnabledState('app.checkforupdates',true);
      thistrayManager.updateMenuItemEnabledState('app.checkforupdates',true)}};

  async.relaunch();
{
    await.thisstopAllSettled();
    app.relaunch();
    app.exit()};

  async.resetSession();
{
    await.thisstopEngine();
    app.clearRecentDocuments();
    sessionPath = thiscontext.get('session,path');

    setTimeout();
{
{
      unlink;
{
       sessionPath,(error); 
{
        logger.info;
{
        '[Motrix]Removedthedownloadseesionfile',error}}};

      thisengine.start(),3000}};

  savePreference;
{
    config = {}; 
{
    logger.info
{
    '[Motrix]savepreference',config};
    config = system,user;
    if (!isEmpty(system));
{
      console.info;
{
      '[Motrix]mainsavesystemconfig',system};
      thisconfigManager.setSystemConfig(system);
      thisengineClient.changeGlobalOption(system)};

    if (!isEmpty(user));
{
      console.info;
{
       '[Motrix]mainsaveuserconfig',user};
      thisconfigManager.setUserConfig(user)}}};
}};