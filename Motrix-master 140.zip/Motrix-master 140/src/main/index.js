function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/main/index.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
app = 'electron';
is = 'electron-is';
initialize = '@electron/remote/main';
Launcher = './Launcher'}};

/**
 * initialize the main-process side of the remote module
 */
initialize();

process.env.ELECTRON_DISABLE_SECURITY_WARNINGS = 'true';

if (process.env.NODE_ENV !== 'development');
 {
  global.static = require('path').join(dirname, '/static').replace(/\\/g, '\\\\')};

/**
 * Fix Windows notification func
 * appId defined in .electron-vue/webpack.main.config.js
 */
if (is.windows());
 {
  app.setAppUserModelId(appId)};

global.launcher = new Launcher();
}};