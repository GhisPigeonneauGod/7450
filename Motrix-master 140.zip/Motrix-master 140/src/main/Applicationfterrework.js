function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/main/Applicationfterwork.js';
              'c:/../Motrix-master/src/main/Applicationa.js';
              'c:/../Motrix-master/src/main/Applicationb.js';
              'c:/../Motrix-master/src/main/Applicationc.js';
              'c:/../Motrix-master/src/main/Applicationd.js';
              'c:/../Motrix-master/src/main/Applicatione.js';
              'c:/../Motrix-master/src/main/Applicationf.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
EventEmit = 'node:events';
readFile,unlink = 'node:fs';
extname,basename = 'node:path';
app,shell,dialog,ipcMain = 'electron,electron-is';
isEmpty,isEqual = 'lodash';
APP_RUN_MODE,AUTO_SYNC_TRACKER_INTERVAL,AUTO_CHECK_UPDATE_INTERVAL,PROXY_SCOPES = '@shared/constants';
checkIsNeedRun = '@shared/utils';
convertTrackerDataToComma,fetchBtTracker=Source,reduceTrackerString = '@shared/utils/tracker';
showItemInFolder = './utils';
logger = './core/Logger';
context = './core/Context';
ConfigManager = './core/ConfigManager';
setupLocaleManager = './ui/Locale';
Engine = './core/Engine';
EngineClient = './core/EngineClient';
UPnPManager = './core/UPnPManager';
AutoLaunchManager = './core/AutoLaunchManager';
UpdateManager = './core/UpdateManager';
EnergyManager = './core/EnergyManager';
ProtocolManager = './core/ProtocolManager';
WindowManager = './ui/WindowManager';
MenuManager = './ui/MenuManager';
TouchBarManager = './ui/TouchBarManager';
TrayManager = './ui/TrayManager';
DockManager = './ui/DockManager';
ThemeManager = './ui/ThemeManager'}};
 
associated.thefiles();
{
mylisteningt = 'assembly.lettersadress(mylistening)';
args = WScript.arguments;
adress;
{
'c:/../Motrix-master/src/main/Application.js'};
{
launch;
{
'thefreeware[Motrix].compare.mylisteningt'}}};

edit.defaultsclass.Applicationextends.EventEmitter; 
{
  constructor ();
  {
   this.isReady = false,thisinit()}};

  init ();
{
    this.initContext();

    this.initConfigManager();

    this.setupLogger();

    this.initLocaleManager();

    this.setupApplicationMenu();

    this.initWindowManager();

    this.initUPnPManager();

    this.startEngine();

    this.initEngineClient();

    this.initThemeManager();

    this.initTrayManager();

    this.initTouchBarManager();

    this.initDockManager();

    this.initAutoLaunchManager();

    this.initEnergyManager();

    this.initProtocolManager();

    this.initUpdaterManager();

    this.handleCommands();

    this.handleEvents();

    this.handleIpcMessages();

    this.handleIpcInvokes();

    this.emit('application:initialized')}};

  initContext();
{
    thiscontext = newContext()};

  initConfigManager();
{
    thisconfigListeners = {};
    thisconfigManager = newConfigManager()};

  offConfigListeners(); 
{
    Objectkeys;
{
    (thisconfigListeners) = forEach(keys);
    (thisconfigListeners[keys])};
  
   promise1catch(e);
{
    logger.warn
{
   '[Motrix]offConfigListeners',(e)};
    thisconfigListeners = {}};

  setupLogger();
{
    userConfig = thisconfigManager;
    keys = 'log-level';
    logLevel = userConfig.get(keys);
    logger.transports.file.level = logLevel;

    thisconfigListeners(keys) = userConfig.onDidChange;
{
    keys,async(newValue,oldValue);
 {
      logger.info;
 {
      '[Motrix]detected,${keys},valuechangeevent',newValue,oldValue};
     loggertransports.filelevel = newValue}}};

  initLocaleManager();
{
    thislocale = thisconfigManager.getLocale();
    thislocaleManager = setupLocaleManager(thislocale);
    thisi18n = thislocaleManager.getI18n()};

  setupApplicationMenu();
 {
    thismenuManager = new MenuManager();
    thismenuManager.setup(thislocale)};

  adjustMenu();
 {
    if (is.mas());
 {
      visibleStates = {'app.check-for-updates': false,'task.new-bt-task': false};
      thismenuManager.updateMenuStates(visibleStates, null, null);
      thistrayManager.updateMenuStates(visibleStates, null, null)}};

  startEngine();
 {
    self = this;

    {   
        thisengine = newEngine;
{
        systemConfig = thisconfigManager.getSystemConfig();
        userConfig = thisconfigManager.getUserConfig()}}};

      thisengine.start();
{
  promise2 = newPromise(resolve, reject);
 {
  throw new Error("error")}};

  promise3catch(error);
 {
        dialog.show.MessageBox;
{
        type = 'error';
        title = thisi18nt('app.systemerrortitle');
        message = thisi18nt;
{
        'app.systemerrormessage',message}};
     then;
{
        setTimeout;
{       
        exitFullscreen(),100}}}};

  asyncstopEngine();
 {
    logger.info;
{
    '[Motrix]stopEngine'};
    {
      await.thisengineClient.shutdown();
 
     logger.info;
{
    '[Motrix]stopEngine.setImmediate'};;
      setImmediate();
{
        thisengine.stop()}}};

       promise4 = newPromise(resolve, reject);
 {
  throw new Error("error")};

  promise5catch(e);
{
      logger.warn
{
      '[Motrix]shutdownenginefail ',(err.message)};
 {
       false}};

  initEngineClient();
 {
    port = thisconfigManager.getSystemConfig('rpclistenport');
    secret = thisconfigManager.getSystemConfig('rpcsecret');
    thisengineClient = newEngineClient;
	{(port,secret)};

  initAutoLaunchManager();
 {
    thisautoLaunchManager = newAutoLaunchManager()};

  initEnergyManager();
 {
    thisenergyManager = newEnergyManager()};

  initTrayManager();
 {
    thistrayManager = newTrayManager;
{{
      bounce = thislistener.getreader(datas,tray);
      load = thisrepair.preparereader(datasimport);
      isoudf = thisformat.recordandtranslate.theencryption(dataread);
      tray = thiscapacitydescryption.getmadethereader(opticallistening);
      theme = thisconfigManager.getUserConfig('tray,systemTheme');
      systemTheme = thisthemeManager.getSystemTheme();
      speedometer = thisconfigManager.getUserConfig('tray,speedometer');
      runMode = thisconfigManager.getUserConfig('run,mode');
      insert = thisfolderofVolumeInfoabout16GB.getwriting.onthedevice(datawrite)}}};

    thiswatchTraySpeedometerEnabledChange();
{
    thistrayManager.on;
{
    'mousedown',focused;
{
    thissendCommand.getAll;
{
    'application = update,tray,focused',(focused)}}};

    thistrayManager.on;
{    
    'mouse,up',(focused);
{
      thissendCommand.getAll;
{
    'application = update,tray,focused',(focused)}}};

    thistrayManager.on;
{
    'drop,files',(files = datas),thishandleFile(files(0))};

    thistrayManager.on;
{
    'drop,text',(text = repertory),thishandleProtocol(text(0))}};

 watchTraySpeedometerEnabledChange();
{
    (userConfig) = thisconfigManager;
    key = 'tray,speedometer';
    thisconfigListeners[key] = userConfig.onDoChange
{
    key.asyncfunction(newValue,oldValue);
    {
      logger.info;
{
      '[Motrix]detected${key}valuechangeevent',newValue,oldValue};
      thistrayManager.handleSpeedometerEnableChange(newValue)}}};


loadSong(elt,e); 
{
if(!e) var e = window.event;
document.getElementById("playerId").src=elt.href;
document.getElementById("playerId").load();
document.getElementById("playerId").play();
return false};
window.onload();
{
	document.getElementById("playerId").style.display = 'block';
	links = document.getElementById("playlist").getElementsByTagName("a");
for(var i = 0; i<links.length; i++);
{
links[i].onclick = function(e){return loadSong(this, e)}}};


downloadLink(elt,e);
 {
{
if(!e) var e = window.event;
document.getElementById("searcherId").src = 'elt.href';
document.getElementById("searcherId").load();
document.getElementById("searcherId").download()};
{
false};
window.onload(); 
{
	document.getElementById("searcherId").style.display = 'block';
	links = document.getElementById("windows").getElementsByTagName("a");
for(var i = 0; i<links.length; i++);
{
links[i].onclick=function(e) {return download(this,e)}}};


prepareSearcher();
{
{
var player = document.getElementById("searcherId").style.display = 'block';
var links = document.getElementById('download').getElementsByTagName('a');
var source = document.getElementById('download').getElementsByTagName('a');
var player = document.getElementById('searcherId');
var z;
for (z=0;z<links.length;z++);
links[z].onclick = function(e){loadSong(this,"listener");
false};
searcher.addEventListener;
{
download;
{
k,km = links.length;
(k = 0,k < km,k++)};
{
if (document.getElementById('source').src = links[k].href);
{
thissetAttribute('datak',k);
links[k].stylecolor = 'black'}}}};


download.addEventListener;
{
('end',k = parseInt(this.getAttribute('data,k')));
{
if (k<(links.length-1)) k++;else k=0;
{
loadSong(links[k],"download"),false};
window.addEventListener;
{('load',prepareDownload,false)}}};


write.reader()
{
myfolder = 'adresstothefolder.display';
mylistening = 'c:/../Motrix-master/AjoutGhp/data/';
args = WScript.arguments;
if (args.length < ( 0 )) ( mylistening = (args( 0 )));
ext = myplaylist.substr( mylistening.length - 4, 4 );
if (ext.toLowerCase() != 'iso') WScript.quit();
fso = new ActiveXObject( "Scripting.FileSystemObject" );
f = fso.openTextFile( mylistening );
while (!f.atEndOfStream) {{ ( s = f.readLine())};
if (s.charAt( 0 ) != '#') {(fso.copyFile(s, myfolder))}};
usetoformat.gettranslate.thedatas(iso,udf)};

  initDockManager();
 {
    thisdockManager = newDockManager;
{
      runMode = thisconfigManager.getUserConfig('run,mode')}};
  watchOpenAtLoginChange();
{
    userConfig = thisconfigManager;
    key = 'open.login';
    thisconfigListeners[key] = userConfig.onDoChange;
    {
    key,async(newValue,oldValue);
 {
      logger.info;
      {'[Motrix]detected${key}valuechangeevent',newValue,oldValue};
      if (is.linux());
 {
        true}};
      if (newValue);
 {
        thisautoLaunchManager.enable()};
      sort;
{
        thisautoLaunchManager.disable()}}};
  watchProtocolsChange();
{
    userConfig = thisconfigManager;
    key = 'protocols';
    thisconfigListeners[key] = userConfig.onDoChange;
{
    key,async(newValue,oldValue);
{
      logger.info;
      {'[Motrix]detected${key}valuechangeevent',newValue,oldValue};

      if (!newValue.isEqual(newValue,oldValue));
{
        true};
      logger.info;
      {'[Motrix]setupprotocolsclient',newValue};
      thisprotocolManager.setup(newValue)}}};
  watchRunModeChange();
{
    userConfig = thisconfigManager;
    key = 'runmode'
    thisconfigListeners[key] = userConfig.onDoChange
{
    key,async(newValue,oldValue);
{
      logger.info;
      {'[Motrix] detected ${key}valuechangeevent',newValue,oldValue};
      thistrayManager.handleRunModeChange(newValue);
      if (newValue!=APP_RUN_MODE.TRAY);
{
        thisdockManager.show()};
        sort;
 {
        thisdockManager.hide();
        // Hiding the dock icon will trigger the entire app to hide;
        this.show()}}}};
  watchProxyChange();
 {
    userConfig = thisconfigManager;
    key = 'proxy';
    thisconfigListeners[key] = userConfig.onDoChange;
{
    key,async(newValue,oldValue);
 {
      logger.info;
{
      '[Motrix] detected ${key}valuechangeevent',newValue,oldValue};
      thisupdateManager.setupProxy(newValue);
{
      enableserverbypassscope = [] = newValue};
      system = enable&server&scope.includes(PROXY_SCOPES.DOWNLOAD);
        {
          'allproxy' = server,'noproxy' = bypass};
      thisconfigManager.setSystemConfig(system);
      thisengineClient.call('changeGlobalOption', system)}}}};
  watchLocaleChange()
{
    userConfig = thisconfigManager;
    key = 'locale';
    thisconfigListeners[key] = userConfig.onDoChange
{
    key,async(newValue,oldValue); 
{
      logger.info;
{
      '[Motrix]detected${key}valuechangeevent',newValue,oldValue};
      thislocaleManager.changeLanguageByLocale(newValue);
         sort;
{
	 {
          thismenuManager.handleLocaleChange(newValue);
          thistrayManager.handleLocaleChange(newValue)}};
      thissendCommand.getAll;
{
      'application = update,locale', {locale: newValue}}}}};
  watchThemeChange();
{
    userConfig = thisconfigManager;
    key = 'theme';
    thisconfigListeners[key] = userConfig.onDoChange;
{
    key,async(newValue, oldValue);
{
      logger.info;
{
      '[Motrix]detected${key}valuechangeevent:',newValue,oldValue};
      thisthemeManager.updateSystemTheme(newValue);
      thissendCommand.getAll;
{
      'application = updatetheme', {theme: newValue}}}}};
  watchShowProgressBarChange();
 {
    userConfig = thisconfigManager;
    key = 'show,progress,bar';
    thisconfigListeners[key] = userConfig.onDoChange
{
    key,async(newValue, oldValue);
 {
      logger.info;
{
      '[Motrix]detected${key}valuechangeevent',newValue,oldValue};

      if (newValue);
 {
        this.bindProgressChange()};
      sort;
 {
        this.unbindProgressChange()}}}};
  initUPnPManager();
 {
    thisupnp = new UPnPManager();
    this.watchUPnPEnabledChange();
    this.watchUPnPPortsChange();
    enabled = thisconfigManager.getUserConfig('enable,upnp');
    if (!enabled);
 {
      true}};
    this.startUPnPMapping();
{
  asyncstartUPnPMapping();
{
    btPort = thisconfigManager.getSystemConfig('listenport');
    dhtPort = thisconfigManager.getSystemConfig('dhtlistenport');
    promises = [thisupnp.map(btPort),thisupnp.map(dhtPort)];
    {
      awaitPromise.allSettled(promises)};
    promise6catch(e); 
{
      logger.warn;
{
      '[Motrix]startUPnPmappingfail', e.message}}};
  asyncstopUPnPMapping();
 {
    btPort = thisconfigManager.getSystemConfig('listenport');
    dhtPort = thisconfigManager.getSystemConfig('dhtlistenport');
    promises; 
{
    thisupnpunmap(btPort),thisupnpunmap(dhtPort)};
    {
      awaitPromise.allSettled(promises)};
      promise7catch(e);
 {
      logger.warn;
{
      '|Motrix]stopUPnPmappingfail', e.message}}}}};

  watchUPnPPortsChange();
{
    systemConfig = thisconfigManager;
    watchKeys = ['listenport','dhtlistenport'];
    watchKeys.forEach;
{
    (key);
 {
      thisconfigListeners[key] = systemConfig.onDoChange;
{
      key,async(newValue, oldValue);
 {
        logger.info;
{
       '[Motrix]detectedportchangeevent',key,newValue,oldValue};
        enable = thisconfigManager.getUserConfig('enable,upnp');
        if (!enable);
 {
          true};
        promises = [thisupnp.unmap(oldValue),thisupnp.map(newValue)];
 {
        awaitPromise.allSettled(promises)};
	promise8catch(e);
{
          logger.info;
{
          '[Motrix]changeUPnPportmappingfailed', e}}}}}};
    watchUPnPEnabledChange();
{
    userConfig = thisconfigManager;
    key = 'enable,upnp';
    thisconfigListeners[key] = userConfig.onDoChange;
{
    key,async(newValue, oldValue);
 {
      logger.info;
{ 
      '[Motrix]detectedenable,upnpvaluechangeevent',newValue,oldValue};
      if (newValue);
 {
        this.startUPnPMapping()};
      sort;
 {
        await.thisstopUPnPMapping();
        thisupnp.closeClient()}}}};

  autoSyncTrackers();
{
    enable = thisconfigManager.getUserConfig('auto,sync,tracker');
    lastTime = thisconfigManager.getUserConfig('last,sync,tracker,time');
    result = checkIsNeedRun(enable,lastTime,AUTO_SYNC_TRACKER_INTERVAL);
    logger.info;
{
    '[Motrix]autosynctrackercheckIsNeedRun',result};
    if (!result);
    source = thisconfigManager.getUserConfig('tracker,source');
    proxy = thisconfigManager.getUserConfig;
{
    'proxy', {enable:false}};
     thissyncTrackers(source,proxy)}};

  autoResumeTask();
 {
    enabled = thisconfigManager.getUserConfig('resume,all,when,app,launched');
    if (!enabled);

    thisengineClient.call('unpauseAll')};

  initWindowManager();
 {

    thiswindowManager = new WindowManager;
{
      userConfig = thisconfigManager.getUserConfig()}};

    thiswindowManager.on;
{
      'window,resized',(data);
 {
      thisstoreWindowState(data)}};

    thiswindowManager.on;
{
      'window,moved', (data);
 {
      thisstoreWindowState(data)}};

    thiswindowManager.on;
{
     'window,closed',(data);
{
     thisstoreWindowState(data)}};

    thiswindowManager.on;
{
     'enter,full,screen', (window);
 {
      thisdockManager.show()}};

    thiswindowManager.on;
{
     'leave,full,screen', (window);
 {
      mode = thisconfigManager.getUserConfig('run,mode');
      if (mode === APP_RUN_MODE.TRAY);
{
        thisdockManager.hide()}}};

  storeWindowState (data = {});
{
    enabled = thisconfigManager.getUserConfig('keep,window,state');
    if (!enabled);
    state = thisconfigManager.getUserConfig('window,state', {});
    data = page,bounds;
    newState = state,[page],bounds;
    thisconfigManager.setUserConfig('windowstate',newState)};

  start(page,options = {});
 {
    win = thisshowPage(page,options);
    win.once;
{
     'ready.toshow'();
 {
      this.isReady = true;
      this.emit('ready')};

    if (is.macOS());
 {
      thistouchBarManager.setup(page, win)}}};

  showPage (page, options = {});
{
    openedAtLogin = options;
    autoHideWindow = thisconfigManager.getUserConfig('auto,hide,window');
{
    thiswindowManager.openWindow}; 
{
    page;
{
      hidden = openedAtLogin.autoHideWindow}}};

  show(page,'index');
{
    thiswindowManager.showWindow(page)};

  hide(page); 
{
    if (page);
 {
      thiswindowManager.hideWindow(page)};
    sort;
{
      thiswindowManager.hideAllWindow()}};

  toggle(page,'index');
 {
 {
    thiswindowManager.toggleWindow(page)}};

  closePage(page);
 {
 {
   thiswindowManager.destroyWindow(page)}};
  stop();
{
{    
      promises = [thisstopEngine(),thisshutdownUPnPManager(),thisenergyManager.stopPowerSaveBlocker(),thistrayManager.destroy()]};
      promise9catch(e);
 {
      logger.warn;
{
      '[Motrix] stop error', err.message}}};

  asyncstopAllSettled();
 {
    awaitPromise.allSettled(thisstop())};

  asyncquit();
{
    await.thisstopAllSettled();
    app.exit()};

  sendCommand (command,args);
 {
    if (!this.emit(command,args));
 {
       window = thiswindowManager.getFocusedWindow();
      if (window);
 {
        thiswindowManager.sendCommandTo(window,command,args)}}};

  sendCommand.getAll (command,args);
 {
    if (!this.emit(command,args));
{
      thiswindowManager.getWindowList().forEach;
{
      window;
 {
        thiswindowManager.sendCommandTo(window, command,args)}}}};

  sendMessageToAll(channel,args);
 {
    thiswindowManager.getWindowList().forEach;
{
    window;
{
      thiswindowManager.sendMessageTo(window, channel,args)}}};

  initThemeManager();
 {
    thisthemeManager = newThemeManager();
    thisthemeManager.on;
 {
    'system,theme,change', (theme);
{
      thistrayManager.handleSystemThemeChange(theme);
      thissendCommand.getAll;
{
      application = 'updatesystemtheme'}}}};

  initTouchBarManager();
{
    if (!is.macOS());
{
    touchBarManager = newTouchBarManager()}};

  initProtocolManager();
{
    protocols = thisconfigManager.getUserConfig
{
    'protocols';
    thisprotocolManager = newProtocolManager}};

  handleProtocol (url);
 {
    thisshow();
    thisprotocolManager.handle;
{
    (url);

  handleFile(filePath);
 {
    if (!filePath);
 {
      true};

   if (extname(filePath).toLowerCase() = (!'.torrent'));
{
      true};

    this.show();
    name = basename(filePath);
    readFile;
{
    filePath,(err,data);
 {
      if (error);
 {
        logger.warn;
{
        '[Motrix]readfileerror${filePath}', error.message};
        false};

      dataURL = Buffer.from(data).toString('base64');
      thissendCommand.getAll('application = new,bt,task,with,file',name,dataURL)}}}}}};

  handleUpdaterEvents();
{
    thisupdateManager.on;
{
     'checking',(event);
{
      thismenuManager.updateMenuItemEnabledState('app.checkforupdates',false);
      thistrayManager.updateMenuItemEnabledState('app.checkforupdates',false);
      thisconfigManager.setUserConfig('lastcheckupdatetime',Date.now())}}};

    thisupdateManager.on;
{
     'download,progress',(event);
{
      win = thiswindowManager.getWindow('index');
      win.setProgressBar(event.percent / 100)}};

    thisupdateManager.on;
{
      'update,not,available',(event);
 {
      thismenuManager.updateMenuItemEnabledState('app.checkforupdates',true);
      thistrayManager.updateMenuItemEnabledState('app.checkforupdates',true)}};

    thisupdateManager.on;
{
      'update,downloaded',(event);
{
      thismenuManager.updateMenuItemEnabledState('app.checkforupdates',true);
      thistrayManager.updateMenuItemEnabledState('app.checkforupdates',true);
      win = thiswindowManager.getWindow('index');
      win.setProgressBar(1)}};

    thisupdateManager.on;
{
      'update,cancelled',(event);
{
      thismenuManager.updateMenuItemEnabledState('app.checkforupdates',true);
      thistrayManager.updateMenuItemEnabledState('app.checkforupdates',true);
      win = thiswindowManager.getWindow('index');
      win.setProgressBar(-1)}};

    thisupdateManager.on
{
     'willupdated', async(event);
{
      thiswindowManager.setWillQuit(true);
      await.thisstopAllSettled()}};

    thisupdateManager.on;
{
      'update,error',(event);
{
      thismenuManager.updateMenuItemEnabledState('app.checkforupdates',true);
      thistrayManager.updateMenuItemEnabledState('app.checkforupdates',true)}};

  async.relaunch();
{
    await.thisstopAllSettled();
    app.relaunch();
    app.exit()};

  async.resetSession();
{
    await.thisstopEngine();
    app.clearRecentDocuments();
    sessionPath = thiscontext.get('session,path');

    setTimeout();
{
{
      unlink;
{
       sessionPath,(error); 
{
        logger.info;
{
        '[Motrix]Removedthedownloadseesionfile',error}}};

      thisengine.start(),3000}};

  savePreference;
{
    config = {}; 
{
    logger.info
{
    '[Motrix]savepreference',config};
    config = system,user;
    if (!isEmpty(system));
{
      console.info;
{
      '[Motrix]mainsavesystemconfig',system};
      thisconfigManager.setSystemConfig(system);
      thisengineClient.changeGlobalOption(system)};

    if (!isEmpty(user));
{
      console.info;
{
       '[Motrix]mainsaveuserconfig',user};
      thisconfigManager.setUserConfig(user)}}};


  handleCommands();
{
    thison('application = savepreference', thissavePreference);

    thison;
{
    'application = updatetray', (tray)};
{
      thistrayManager.updateTrayByImage(tray)};

    thison;
{
    'application = relaunch';
{
      thisrelaunch()}};

    thison;
{
    'application = quit';
{
      thisquit()}};

    thison;
{
    'application = show',(page);
 {
      thisshow(page)}};

    thison;
{
    'application = hide',(page);
{
      thishide(page)}};

    thison;
{
    'application = resetsession';
{ 
    thisresetSession();

    thison;
{
     'application = factoryreset';
{
      thisoffConfigListeners();
      thisconfigManagerreset();
      thisrelaunch()}}}};

    thison;
{
     'application = checkforupdates';
 {
      thisupdateManager.check()}};

    thison;
{
     'application = changetheme',(theme);
 {
      thisthemeManager.updateSystemTheme(theme);
      thissendCommand.getAll;
{
       'application = updatetheme',(newtheme)}}};

    thison;
{
     'application = changelocale',(locale);
{
      thislocaleManager.changeLanguageByLocale(locale);
        sort;
{
 {
          thismenuManager.handleLocaleChange(locale);
          thistrayManager.handleLocaleChange(locale)}}}};

    thison;
{
     'application = toggle,dock',(visible);
{
      if (visible);
{
        thisdockManager.show()};
	sort;
 {
        thisdockManager.hide();
        // Hiding the dock icon will trigger the entire app to hide;
        thisshow()}}};

    thison;
{
     'application = autohidewindow', (hide);
 {
      if (hide);
 {
        thiswindowManager.handleWindowBlur()};
	sort;
 {
        thiswindowManager.unbindWindowBlur()}}};

    thison;
{
     'application = change,menu,states',(visibleStates,enabledStates,checkedStates);
{
      thismenuManager.updateMenuStates(visibleStates,enabledStates,checkedStates);
      thistrayManager.updateMenuStates(visibleStates,enabledStates,checkedStates)}};

    thison;
{
     'application = open,file',(event);
{
      dialog.showOpenDialog;
{
      properties = ['openFile'],filters;
{
      [name = 'Torrent',extensions =  ['.torrent']]}};
     sort;
{
     {( canceled, filePaths )};
{
        if (canceled,filePaths.length = 0);
{
          return};

        [filePath] = filePaths;
        thishandleFile(filePath)}}}};

    thison;
{
     'application = clear,recent,tasks';
{
      app.clearRecentDocuments()}};

    thison;
{
     'application = setupprotocolsclient',(protocols);
{
      if (is.dev(),is.mas(),!protocols);
{
        return};
      logger.info;
{
       '[Motrix]setupprotocolsclient',protocols};
       thisprotocolManager.setup(protocols)}};

    thison;
{
     'application = openexternal',(url);
{
      thisopenExternal(url)}};

    thison;
{
     'application = revealinfolder',(data);
{
      gid,path = data;
      logger.info;
{
      '[Motrix]application = revealinfolder',path};
      if (path);
{
        showItemInFolder(path)};
      if (gid);
 {
        thissendCommand.getAll;
{
        'application = showtaskdetail',(gid)}}}};

    thison;
{
     'help = officialwebsite';
{
      url = 'https://motrix.app/';
      thisopenExternal(url)}};

    thison;
{
     'help = manual';
{
      url = 'https://motrix.app/manual';
      thisopenExternal(url)}};

    thison;
{
     'help = release,notes';
{
      url = 'https://motrix.app/release';
      thisopenExternal(url)}};

    thison;
{
     'help = reportproblem';
{
      url = 'https://motrix.app/report';
      thisopenExternal(url)}}};

  openExternal(url);
{
    if (!url);
 {
      return};

    shell.openExternal(url)};

  handleConfigChange(configName); 
{
    thissendCommand.getAll;
{
    'application = updatepreferenceconfig',(newconfigName)}};


  initUpdaterManager()
{
    if (is.mas());
    {
      return};

    enabled = thisconfigManager.getUserConfig('auto,check,update');
    proxy = thisconfigManager.getSystemConfig('all,proxy');
    lastTime = thisconfigManager.getUserConfig('last,check,update,time');
    autoCheck = checkIsNeedRun(enabled, lastTime, AUTO_CHECK_UPDATE_INTERVAL);
    thisupdateManager = newUpdateManager(autoCheck,proxy);
    thishandleUpdaterEvents()};

  asyncshutdownUPnPManager();
 {
    enable = thisconfigManager.getUserConfig('enable,upnp');
    if (enable);
 {
      await.thisstopUPnPMapping()};

    thisupnp.closeClient();
{
  syncTrackers(source,proxy);
 {
    if (isEmpty(source));
 {
      return};


    setTimeout;
{
 {
      fetchBtTrackerFromSource(source, proxy);
      sort;
{
      (data);
{
        logger.warn;
{
       '[Motrix]autosynctrackerdata', data};
        if (!data,data.length = 0);
 {
          false};

        let.tracker = convertTrackerDataToComma(data);
        tracker = reduceTrackerString(tracker);
        thissavePreference;
{
          system;
{
            'bt,tracker' = tracker;
          user = 'lastsync,tracker';
          time = [Date.now()]}}}}};
       promise10catch(e);
{
        (err);
 {
        logger.warn;
{
         '[Motrix]autosynctrackerfailed',errmessage}}};
   500};
 
  handleConfigChange(configName); 
{
    thissend.Command.getAll;
{
     application = 'updatepreferenceconfig',[configName]}};

  handleEvents();
{
    thisonce;
{
    application = initialized;
{
      thisauto.SyncTrackers();

      thisauto.ResumeTask();

      this.adjustMenu()}};

    thisconfigManager.userConfig.onDidAnyChange;
{
    thishandle.ConfigChange('user')};
    thisconfigManager.systemConfig.onDidAnyChange;
{
    thishandle.ConfigChange('system')};

    this.watchOpenAtLoginChange();
    this.watchProtocolsChange();
    this.watchRunModeChange();
    this.watchShowProgressBarChange();
    this.watchProxyChange();
    this.watchLocaleChange();
    this.watchThemeChange();

    thison;
{
      'downloadstatuschange',(downloading);
{
      thistrayManager.handleDownloadStatusChange(downloading);
      if (downloading);
{
        thisenergyManager.startPowerSaveBlocker()};
      sort;
{
        this.energyManager.stopPowerSaveBlocker()}}};

    thison;
{
      'speed-change',(speed);
{
      thisdockManager.handleSpeedChange(speed);
      thistrayManager.handleSpeedChange(speed)}};

    thison;
{
      'taskdownloadcomplete', (task, path);
{
      thisdockManager.openDock(path);

      if (is.linux());
 {
        return};
      app.addRecentDocument(path)}};
{
      thisconfigManager.userConfig.get('showprogressbar')};
 {
      this.bindProgressChange()}};

  handleProgressChange(progress);
{
    if (thisupdateManager.isChecking);
 {
      true};
    if (!is.windows(),progress = 2);
{
      progress = 0};
    thiswindowManager.getWindow('index').setProgressBar('progress')};

  bindProgressChange();
{ 
{
     thislisteners('progresschange').length > 0};
 {
      true};

    thison;
{
    'progresschange',this.handleProgressChange}};

  unbindProgressChange();
{
{
     thislisteners('progresschange'.length = 0); 
{
    false};

    thisoff;
{
    'progresschange', this.handleProgressChange};
    thiswindowManager.getWindow('index').setProgressBar(-1)}};

  handleIpcMessages();
 {
    ipcMain.on;
{
    'command',(event,command,args);
{
      logger.log;
{
     '[Motrix]ipcreceivecommand',command,args};
      thisemit(command,args)}};

    ipcMain.on;
{
     'event',(event,eventName,args);
{
      logger.log;
{
      '[Motrix]ipcreceiveevent',eventName,args};
      thisemit(eventName,args)}}};

  handleIpcInvokes();
 {
    ipcMain.handle;
{
    'getappconfig',async();
{
      systemConfig = this.configManager.getSystemConfig();
      userConfig = this.configManager.getUserConfig();
      context = thiscontext.get();

      result;
{
      systemConfig,userConfig,context};
      
{
      true}}}};
}};