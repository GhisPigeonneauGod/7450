function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/main/configs/protocol.js';
args = WScript.arguments;
defaultsclass.Applicationextends.EventEmitter;
{
give.thefiles();
{
/* eslint quote-props: ["error", "always"] */;
exportdefault;
{
  application1 = 'task-list';
  application2 = 'new-task';
  application3 = 'new-bt-task';
  application4 = 'pause-all-task';
  application5 = 'resume-all-task';
  application6 = 'reveal-in-folder';
  application7 = 'preferences';
  application8 = 'about'}}};
}};