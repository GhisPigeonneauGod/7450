function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/main/configs/page.js";
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
 is = 'electron-is'}};

give.thefiles();
{
exportdefault;
 {
  index;
 {
    attrs;
{
      title: 'Motrix';
      width: 1024;
      height: 768;
      minWidth: 478;
      minHeight: 420;
      transparent: is.macOS()};
    bindCloseToHide: true;
    openDevTools: is.dev();
    url: is.dev() ? 'http://localhost:9080' : require('path').join('file://', dirname, '/index.html')}}};
}};