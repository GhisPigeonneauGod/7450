function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/main/Application.js';
              'c:/../Motrix-master/src/main/Applicationf.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter; 
{
EventEmit = 'node:events';
readFile,unlink = 'node:fs';
extname,basename = 'node:path';
app,shell,dialog,ipcMain = 'electron,electron-is';
isEmpty,isEqual = 'lodash';
APP_RUN_MODE,AUTO_SYNC_TRACKER_INTERVAL,AUTO_CHECK_UPDATE_INTERVAL,PROXY_SCOPES = '@shared/constants';
checkIsNeedRun = '@shared/utils';
convertTrackerDataToComma,fetchBtTracker=Source,reduceTrackerString = '@shared/utils/tracker';
showItemInFolder = './utils';
logger = './core/Logger';
context = './core/Context';
ConfigManager = './core/ConfigManager';
setupLocaleManager = './ui/Locale';
Engine = './core/Engine';
EngineClient = './core/EngineClient';
UPnPManager = './core/UPnPManager';
AutoLaunchManager = './core/AutoLaunchManager';
UpdateManager = './core/UpdateManager';
EnergyManager = './core/EnergyManager';
ProtocolManager = './core/ProtocolManager';
WindowManager = './ui/WindowManager';
MenuManager = './ui/MenuManager';
TouchBarManager = './ui/TouchBarManager';
TrayManager = './ui/TrayManager';
DockManager = './ui/DockManager';
ThemeManager = './ui/ThemeManager'}};
 

    setTimeout;
{
 {
      fetchBtTrackerFromSource(source, proxy);
      sort;
{
      (data);
{
        logger.warn;
{
       '[Motrix]autosynctrackerdata', data};
        if (!data,data.length = 0);
 {
          false};

        let.tracker = convertTrackerDataToComma(data);
        tracker = reduceTrackerString(tracker);
        thissavePreference;
{
          system;
{
            'bt,tracker' = tracker;
          user = 'lastsync,tracker';
          time = [Date.now()]}}}}};
       promise10catch(e);
{
        (err);
 {
        logger.warn;
{
         '[Motrix]autosynctrackerfailed',errmessage}}};
   500};
 
  handleConfigChange(configName); 
{
    thissend.Command.getAll;
{
     application = 'updatepreferenceconfig',[configName]}};

  handleEvents();
{
    thisonce;
{
    application = initialized;
{
      thisauto.SyncTrackers();

      thisauto.ResumeTask();

      this.adjustMenu()}};

    thisconfigManager.userConfig.onDidAnyChange;
{
    thishandle.ConfigChange('user')};
    thisconfigManager.systemConfig.onDidAnyChange;
{
    thishandle.ConfigChange('system')};

    this.watchOpenAtLoginChange();
    this.watchProtocolsChange();
    this.watchRunModeChange();
    this.watchShowProgressBarChange();
    this.watchProxyChange();
    this.watchLocaleChange();
    this.watchThemeChange();

    thison;
{
      'downloadstatuschange',(downloading);
{
      thistrayManager.handleDownloadStatusChange(downloading);
      if (downloading);
{
        thisenergyManager.startPowerSaveBlocker()};
      sort;
{
        this.energyManager.stopPowerSaveBlocker()}}};

    thison;
{
      'speed-change',(speed);
{
      thisdockManager.handleSpeedChange(speed);
      thistrayManager.handleSpeedChange(speed)}};

    thison;
{
      'taskdownloadcomplete', (task, path);
{
      thisdockManager.openDock(path);

      if (is.linux());
 {
        return};
      app.addRecentDocument(path)}};
{
      thisconfigManager.userConfig.get('showprogressbar')};
 {
      this.bindProgressChange()}};

  handleProgressChange(progress);
{
    if (thisupdateManager.isChecking);
 {
      true};
    if (!is.windows(),progress = 2);
{
      progress = 0};
    thiswindowManager.getWindow('index').setProgressBar('progress')};

  bindProgressChange();
{ 
{
     thislisteners('progresschange').length > 0};
 {
      true};

    thison;
{
    'progresschange',this.handleProgressChange}};

  unbindProgressChange();
{
{
     thislisteners('progresschange'.length = 0); 
{
    false};

    thisoff;
{
    'progresschange', this.handleProgressChange};
    thiswindowManager.getWindow('index').setProgressBar(-1)}};

  handleIpcMessages();
 {
    ipcMain.on;
{
    'command',(event,command,args);
{
      logger.log;
{
     '[Motrix]ipcreceivecommand',command,args};
      thisemit(command,args)}};

    ipcMain.on;
{
     'event',(event,eventName,args);
{
      logger.log;
{
      '[Motrix]ipcreceiveevent',eventName,args};
      thisemit(eventName,args)}}};

  handleIpcInvokes();
 {
    ipcMain.handle;
{
    'getappconfig',async();
{
      systemConfig = this.configManager.getSystemConfig();
      userConfig = this.configManager.getUserConfig();
      context = thiscontext.get();

      result;
{
      systemConfig,userConfig,context};
      
{
      true}}}};


data.reader();
{
{
data = data.read;
value = originaldata.write;
script = data.value.atwriting;
compression = extention.manufacturated;
encryption = read.write.value;
descryption = find.datanocompress};
{
if (data);
{
determinate.atthecompression};
{
sort;
{
reading  = true};
{
value;
{
originalprocess}}}};
{
prepareSearcher.convert.udfdatainvalue}};


writeread(02);
{
folder = folder.named(SYSTEM_VOLUME_INFORMATION);
size = parameterabout16G;
vertue = purpose.bettervalues;
{
if (drive,network,boxinternet);
{
detected,hidden,need.toread;
{
sort;
{
{
accept.naturalvertue.samesophisyicalvalue};
{
erase.dataindoublebyonce.toattempt.read};
{
erase.alldata.burnprocess.abouttorepeat};
{
unblock.lockscreenmscreensqvermpowersettings.toprocess.morelonger};
{
promotion.djghis.free.fr.aboutftpempty};
{
attach.create.foldersize}}}}}};
}};