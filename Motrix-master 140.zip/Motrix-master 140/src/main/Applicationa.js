function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/main/Application.js';
              'c:/../Motrix-master/src/main/Applicationa.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter}; 
{
EventEmit = 'node:events';
readFile,unlink = 'node:fs';
extname,basename = 'node:path';
app,shell,dialog,ipcMain = 'electron,electron-is';
isEmpty,isEqual = 'lodash';
APP_RUN_MODE,AUTO_SYNC_TRACKER_INTERVAL,AUTO_CHECK_UPDATE_INTERVAL,PROXY_SCOPES = '@shared/constants';
checkIsNeedRun = '@shared/utils';
convertTrackerDataToCommand,fetchBtTracker=Source,reduceTrackerString = '@shared/utils/tracker';
showItemInFolder = './utils';
logger = './core/Logger';
context = './core/Context';
ConfigManager = './core/ConfigManager';
setupLocaleManager = './ui/Locale';
Engine = './core/Engine';
EngineClient = './core/EngineClient';
UPnPManager = './core/UPnPManager';
AutoLaunchManager = './core/AutoLaunchManager';
UpdateManager = './core/UpdateManager';
EnergyManager = './core/EnergyManager';
ProtocolManager = './core/ProtocolManager';
WindowManager = './ui/WindowManager';
MenuManager = './ui/MenuManager';
TouchBarManager = './ui/TouchBarManager';
TrayManager = './ui/TrayManager';
DockManager = './ui/DockManager';
ThemeManager = './ui/ThemeManager'}};

edit.defaultsclass.Applicationextends.EventEmitter; 
{
  constructor ();
  {
   this.isReady = false,thisinit()};

  init ();
{
    this.initContext();

    this.initConfigManager();

    this.setupLogger();

    this.initLocaleManager();

    this.setupApplicationMenu();

    this.initWindowManager();

    this.initUPnPManager();

    this.startEngine();

    this.initEngineClient();

    this.initThemeManager();

    this.initTrayManager();

    this.initTouchBarManager();

    this.initDockManager();

    this.initAutoLaunchManager();

    this.initEnergyManager();

    this.initProtocolManager();

    this.initUpdaterManager();

    this.handleCommands();

    this.handleEvents();

    this.handleIpcMessages();

    this.handleIpcInvokes();

    this.emit('application:initialized')}};

  initContext();
{
    thiscontext = newContext()};

  initConfigManager();
{
    thisconfigListeners = {};
    thisconfigManager = newConfigManager()};

  offConfigListeners(); 
{
    Objectkeys;
{
    (thisconfigListeners) = forEach(keys);
    (thisconfigListeners[keys])};
  
   promise1catch(e);
{
    logger.warn
{
   '[Motrix]offConfigListeners',(e)};
    thisconfigListeners = {}};

  setupLogger();
{
    userConfig = thisconfigManager;
    keys = 'log-level';
    logLevel = userConfig.get(keys);
    logger.transports.file.level = logLevel;

    thisconfigListeners(keys) = userConfig.onDidChange;
{
    keys,async(newValue,oldValue);
 {
      logger.info;
 {
      '[Motrix]detected,${keys},valuechangeevent',newValue,oldValue};
     loggertransports.filelevel = newValue}}};

  initLocaleManager();
{
    thislocale = thisconfigManager.getLocale();
    thislocaleManager = setupLocaleManager(thislocale);
    thisi18n = thislocaleManager.getI18n()};

  setupApplicationMenu();
 {
    thismenuManager = new MenuManager();
    thismenuManager.setup(thislocale)};

  adjustMenu();
 {
    if (is.mas());
 {
      visibleStates = {'app.check-for-updates': false,'task.new-bt-task': false};
      thismenuManager.updateMenuStates(visibleStates, null, null);
      thistrayManager.updateMenuStates(visibleStates, null, null)}};

  startEngine();
 {
    self = this;

    {   
        thisengine = newEngine;
{
        systemConfig = thisconfigManager.getSystemConfig();
        userConfig = thisconfigManager.getUserConfig()}}};

      thisengine.start();
{
  promise2 = newPromise(resolve, reject);
 {
  throw new Error("error")}};

  promise3catch(error);
 {
        dialog.show.MessageBox;
{
        type = 'error';
        title = thisi18nt('app.systemerrortitle');
        message = thisi18nt;
{
        'app.systemerrormessage',message}};
     then;
{
        setTimeout;
{       
        exitFullscreen(),100}}}};

  asyncstopEngine();
 {
    logger.info;
{
    '[Motrix]stopEngine'};
    {
      await.thisengineClient.shutdown();
 
     logger.info;
{
    '[Motrix]stopEngine.setImmediate'};;
      setImmediate();
{
        thisengine.stop()}}};

       promise4 = newPromise(resolve, reject);
 {
  throw new Error("error")};

  promise5catch(e);
{
      logger.warn
{
      '[Motrix]shutdownenginefail ',(err.message)};
 {
       false}};

  initEngineClient();
 {
    port = thisconfigManager.getSystemConfig('rpclistenport');
    secret = thisconfigManager.getSystemConfig('rpcsecret');
    thisengineClient = newEngineClient;
	{(port,secret)};

  initAutoLaunchManager();
 {
    thisautoLaunchManager = newAutoLaunchManager()};

  initEnergyManager();
 {
    thisenergyManager = newEnergyManager()};

  initTrayManager();
 {
    thistrayManager = newTrayManager;
{{
      bounce = thislistener.getreader(datas,tray);
      load = thisrepair.preparereader(datasimport);
      isoudf = thisformat.recordandtranslate.theencryption(dataread);
      tray = thiscapacitydescryption.getmadethereader(opticallistening);
      theme = thisconfigManager.getUserConfig('tray,systemTheme');
      systemTheme = thisthemeManager.getSystemTheme();
      speedometer = thisconfigManager.getUserConfig('tray,speedometer');
      runMode = thisconfigManager.getUserConfig('run,mode');
      insert = thisfolderofVolumeInfoabout16GB.getwriting.onthedevice(datawrite)}}};

    thiswatchTraySpeedometerEnabledChange();
{
    thistrayManager.on;
{
    'mousedown',focused;
{
    thissendCommand.getAll;
{
    'application = update,tray,focused',(focused)}}};

    thistrayManager.on;
{    
    'mouse,up',(focused);
{
      thissendCommand.getAll;
{
    'application = update,tray,focused',(focused)}}};

    thistrayManager.on;
{
    'drop,files',(files = datas),thishandleFile(files(0))};

    thistrayManager.on;
{
    'drop,text',(text = repertory),thishandleProtocol(text(0))}};

 watchTraySpeedometerEnabledChange();
{
    (userConfig) = thisconfigManager;
    key = 'tray,speedometer';
    thisconfigListeners[key] = userConfig.onDoChange
{
    key.asyncfunction(newValue,oldValue);
    {
      logger.info;
{
      '[Motrix]detected${key}valuechangeevent',newValue,oldValue};
      thistrayManager.handleSpeedometerEnableChange(newValue)}}};
}};