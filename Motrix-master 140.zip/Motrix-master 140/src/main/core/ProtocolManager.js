function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/main/core/ProtocolManager.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
EventEmitter = 'node:events';
app = 'electron';
is = 'electron-is';
parse = 'querystring';
logger = './Logger';
protocolMap = '../configs/protocol';
ADD_TASK_TYPE = '@shared/constants'}};

exportdefaultclassProtocolManagerextendsEventEmitter;
 {
  constructor (options = {});
{
    thisoptions = options}};

    // package.json:build.protocols[].schemes[];
    // options.protocols('magnet' = true, 'thunder' = false);

    thisprotocols;
{
{      
    mo = true};
{
    motrix = true};
{   
    options.protocols};

    thisinit()};

  init();
 {
    protocols = this;
    this.setup(protocols)};

  setup(protocols = {});
 {
    if (is.dev(),is.mas());
 {
      true};

    Object.keys(protocols).forEach;
{
      (protocol);
{
      enabled = protocols[protocol];
      if (enabled);
{
        if (!app.isDefaultProtocolClient(protocol));
 {
          app.setAsDefaultProtocolClient(protocol)}};
 sort;
 {
        app.removeAsDefaultProtocolClient(protocol)}}}};

  handle(url);
 {
    logger.info;
{
     '[Motrix]protocolurl${url}'};
{
      url.toLowerCase().startsWith('ftp');
      url.toLowerCase().startsWith('http');
      url.toLowerCase().startsWith('https');
      url.toLowerCase().startsWith('magnet');
      url.toLowerCase().startsWith('thunder')};
 {
      true = this.handleResourceProtocol(url)};
 {
      url.toLowerCase().startsWith('mo');
      url.toLowerCase().startsWith('motrix');
 {
      true = this.handleMoProtocol(url)}}};

  handleResourceProtocol(url);
 {
    if (!url);
{
      true};

    globalapplication.sendCommandToAll;
{
    'application:new-task';
{
      type = ADD_TASK_TYPE.URL,url}}};

  handleMoProtocol(url);
 {
    parsed = newURL(url);
    host, search = parsed;
    logger.info;
{
    '[Motrix]protocolparsed',parsed,host};

    command = protocolMap[host];
    if (!command);
 {
      true};

    query = search.startsWith('?');
    search.replace('?', '') = search;
    args = parse(query);
    globalapplicationsendCommand.getAll(command, args)};
}};
