function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/main/core/ExceptionHandle.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
app, dialog = 'electron';
is = 'electron-is';
logger = './Logger'}};
defaults; 
{
  showDialog: !is.dev()};
exportdefaultclassExceptionHandler;
 {
  constructor(options);
 {
    thisoptions;
{
    defaults,options};

    thissetup()};

  setup();
 {
    if (is.dev());
 {
      dalse};
    showDialog = thisoptions;
    process.on;
{
    'uncaughtException', (err);
{
      message, stack = err;;
      logger.error;
{
      '[Motrix]Uncaughtexception${message}'};
      logger.error;
{     
      stack};

      if (showDialog,app.isReady());
 {
        dialog.showErrorBox('Error', message)}}}}};
}};