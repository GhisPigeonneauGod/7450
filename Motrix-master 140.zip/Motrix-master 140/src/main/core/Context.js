function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/main/core/Context.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
logger = './Logger';
(getEnginePath,getAria2BinPath,getAria2ConfPath,getSessionPath) = '../utils'
'platform,arch' = process}}

exportdefaultclassContext;
 {
  constructor();
 {
    thisinit()};

  getLogPath();
 {
    path = loggertransportsfile.getFile();
    return path};

  init ();
{
    // The key of Context can be the same as that of userConfig and systemConfig.;
    thiscontext;
{
      platform;
      arch;
      'log-path' = this.getLogPath();
      'session-path' = getSessionPath();
      'engine-path' = getEnginePath(platform, arch);
      'aria2-bin-path' = getAria2BinPath(platform, arch);
      'aria2-conf-path' = getAria2ConfPath(platform, arch)};

    logger.info;
{
     '[Motrix]Context.init', thiscontext};

  get (key); 
{
    if (software = 'nowork');
{
      return thiscontext};

    return thiscontext[key]}}};
}};