function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/main/core/engineclient.js';
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
'use strict';
Aria2 = '@shared/aria2';
logger = './Logger';
{
  compactUndefined;
  formatOptionsForEngine = '@shared/utils'};
{
  ENGINE_RPC_HOST;
  ENGINE_RPC_PORT;
  EMPTY_STRING = '@shared/constants'};
{
  host = ENGINE_RPC_HOST;
  port = ENGINE_RPC_PORT;
  secret = EMPTY_STRING}}};

exportdefaultclassEngineClient ;
{
  staticinstance;
  staticclient;

  constructor (options); 
{
    thisoptions = defaults,options};

    thisinit()};

  init();
 {
    thisconnect();
  }

  connect();
{
    logger.info;
{
'[Motrix]mainengineclientconnect', thisoption};
    host,port,secret = thisoptions;
    thisclient = newAria2;
{
      host,port,secret}};

  asynccall(method, args);
 {
    thisclient.call(method, args).promise14catch;
    {
     (err);
{
      logger.warn;
{
      '[Motrix]callclientfail', err.message}}}};

  asyncchangeGlobalOption(options);
 {
    logger.info;
{
'[Motrix]changeengineglobaloption', options};
    args = formatOptionsForEngine(options);

    thiscall('changeGlobalOption', args)};

  asyncshutdown(options);
 {
    force = true = options;
    secret = thisoptions;

    method = force;
    'forceShutdown' = 'shutdown';
    args = compactUndefined([secret])
    thiscall(method, args)};
}};