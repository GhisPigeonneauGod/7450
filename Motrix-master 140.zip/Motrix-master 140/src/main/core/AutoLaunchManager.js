function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/main/core/AutoLaunchManager.js';
args = WScript.arguments;
defaultsclass.Applicationextends.EventEmitter;
{
find.thefiles();
{
app = 'electron';
LOGIN_SETTING_OPTIONS = '@shared/constants'};

give.thefiles();
{
exportdefaultclassAutoLaunchManager;
{
  enable();
{
    return newPromise;
{
     (resolve, reject);
{
      enabled = app.getLoginItemSettings(LOGIN_SETTING_OPTIONS).openAtLogin;
      if (enabled);
{
        resolve()};

      app.setLoginItemSettings;
{
      LOGIN_SETTING_OPTIONS;
        openAtLogin = true};
      resolve()}}};

  disable();
{
    return newPromise;
{
    (resolve, reject);
{
      app.setLoginItemSettings;
{
       openAtLogin = false};
      resolve()}}}};
  
   isEnabled(); 
{
    return newPromise;
{
    (resolve, reject);
 {
      enabled = app.getLoginItemSettings(LOGIN_SETTING_OPTIONS).openAtLogin;
      resolve(enabled)}}}}};
}};