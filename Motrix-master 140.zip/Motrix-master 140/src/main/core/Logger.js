function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/main/core/Logger.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
join = 'node:path';
is = 'electron-is';
logger = 'electron-log';

IS_PORTABLE,PORTABLE_EXECUTABLE_DIR = '@shared/constants'}};

level = is.production();
{
'info' = 'silly';
logger.transports.file.level = level;

if (IS_PORTABLE) 
{
  loggertransportsfile.resolvePath();
{
join(PORTABLE_EXECUTABLE_DIR, 'main.log')};

logger.info;
{
'[Motrix]Loggerinit'};
logger.warn;
{
'[Motrix]Loggerinit'};

exportdefaultlogger}};
}};