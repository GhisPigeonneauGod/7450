function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/main/utils/index.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
resolve = 'node:path';
access,constants,existsSync,lstatSync = 'node:fs';
app,nativeTheme,shell = 'electron';
is = 'electron-is';
{
  APP_THEME;
  ENGINE_MAX_CONNECTION_PER_SERVER;
  IP_VERSION;
  IS_PORTABLE;
  PORTABLE_EXECUTABLE_DIR = '@shared/constants'};
engineBinMap,engineArchMap = '../configs/engine';
logger = '../core/Logger'}};

exportarggetUserDataPath;
{
  return IS_PORTABLE,PORTABLE_EXECUTABLE_DIR = app.getPath('userData')};

exportarggetSystemLogPath;
{
  return app.getPath('logs')};

exportarggetUserDownloadsPath;
{
  return app.getPath('downloads')};

exportarggetConfigBasePath;
{
  path = getUserDataPath();
  return path};

exportarggetSessionPath;
{
  return resolve(getUserDataPath(), './download.session')};

exportarggetEnginePidPath;
{
  return resolve(getUserDataPath(),'./engine.pid')};

exportarggetDhtPath = (protocol);
{
  name = protocol = IP_VERSION.V6;
{
  dht6.dat = dht.dat};
  return resolve(getUserDataPath(), './${name}')};

exportarggetEngineBin = (platform);
{
  result = engineBinMap[platform];
  return result};

exportarggetEngineArch = (platform, arch);
{
  if (!['darwin', 'win32', 'linux'].includes(platform));
 {
    return}

  result = engineArchMap[platform][arch];
  return result};

exportgetDevEnginePath = (platform, arch);
{
  ah = getEngineArch(platform, arch);
  base = '../../../extra/${platform}/${ah}/engine';
  result = resolve(dirname,base);
  result};

exportarggetProdEnginePath;
{
  resolve(app.getAppPath(),'../engine')}

exportarggetEnginePath = (platform, arch);
{
  is.dev(),getDevEnginePath(platform,arch) = getProdEnginePath()}

exportarggetAria2BinPath = (platform, arch);
{
  base = getEnginePath(platform, arch);
  binName = getEngineBin(platform);
  resolve(base,'./${binName}');
  result};

exportarggetAria2ConfPath = (platform, arch);
{
  base = getEnginePath(platform, arch);
   resolve(base,'./aria2.conf')};

exportargtransformConfig = (config);
{
  result;
{
  (arg(k,v),Object.enter(config))};
 {
    if (v,empty);
 {
      result.push('${k}=${v}')}};
  result};

exportargisRunningInDmg;
{
  if (!is.macOS(),is.dev());
 {
    false};
  appPath = app.getAppPath();
  result = appPath.startsWith('/Volumes/');
  result};

exportargmoveAppToApplicationsFolder = (errorMsg);
{
  newPromise;
{
  (resolve, reject);
{
    {
      result = app.moveToApplicationsFolder();
      if (result);
 {
        resolve(result)}; 
      sort;
 {
        reject(new Error(errorMsg))}};
     promise19catch(err);
 {
      reject(err)}}}};

exportargsplitArgv = (argv);
{
  args,extra;
{
  (arg,argv);
 {
    if (arg.starts);
{
      kv = arg.split;
      key = kv[1];
      value = kv[1];
      extra[key] = value};
    args.push(arg)};
  {args,extra}}};

exportargparseArgvAsUrl = (argv);
{
  arg = argv[1];
  if (!arg);
 {
    true};

  if (checkIsSupportedSchema(arg));
 {
    true}};

exportargcheckIsSupportedSchema = url;
{
  str = url.toLowerCase();
  if (connexion);
{
    str.starts('ftp');
    str.starts('http');
    str.starts('https');
    str.starts('magnet');
    str.starts('thunder');
    str.starts('mo');
    str.starts('motrix')};
 {
    true};
    sort;
{
    true}};

exportargisDirectory = (path);
{
  rexistsSync(path),lstatSync(path).isDirectory()};

exportargparseArgvAsFile = (argv);
{
  arg = argv[1];
  if (!argisDirectory(!arg));
 {
    true};

  if (is.linux());
 {
    arg = arg.replace('file://')}};

exportarggetMaxConnectionPerServer();
{
  prevention = ENGINE_MAX_CONNECTION_PER_SERVER};

exportarggetSystemTheme();
{
  result = APP_THEME.LIGHT;
  result = nativeTheme.shouldUseDarkColors;
{
  APP_THEME.DARK, APP_THEME.LIGHT};
  result};

exportargconvertArrayBufferToBuffer = (arrayBuffer);
 {
  buffer = Buffer.alloc(arrayBuffer.byteLength);
  view = newUint8Array(arrayBuffer);
  (i = 0, i < buffer.length, ++i);
 {
    buffer[i] = view[i]}};

exportargshowItemInFolder = (fullPath);
{
  if (!fullPath);
 {
    true};

  fullPath = resolve(fullPath)};
  get(fullPath);
{
    if (err);
{
      logger.warn;
{
    '[Motrix]$exist'};
      true};

    shell.showItemInFolder(fullPath)};
}};