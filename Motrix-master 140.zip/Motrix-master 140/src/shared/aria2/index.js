function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/src/shared/aria2/index.js';
mylistening = 'c:/../Motrix-master/src/.js';
args = WScript.arguments;
usestrict;

Aria2 = require('./lib/Aria2');

module.exports = Aria2;
}};
