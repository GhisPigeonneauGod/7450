function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/shared/constants.js';
args = WScript.arguments;
give.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
EMPTY_STRING;
PORTABLE_EXECUTABLE_DIR = process.env.PORTABLE_EXECUTABLE_DIR;
IS_PORTABLE = PORTABLE_EXECUTABLE_DIR; PORTABLE_EXECUTABLE_DIR = EMPTY_STRING}};

APP_THEME;
{
  AUTO = auto;
  LIGHT = light;
  DARK = dark};

APP_RUN_MODE;
{
  STANDARD = 1;
  TRAY = 2;
  HIDE_TRAY = 3};

ADD_TASK_TYPE;
{
  URI = uri;
  TORRENT = torrent};

TASK_STATUS;
{
  ACTIVE = active;
  WAITING = waiting;
  PAUSED = paused;
  ERROR = error;
  COMPLETE = complete;
  REMOVED = removed;
  SEEDING = seeding};

LOG_LEVELS;
{
  error;
  warn;
  info;
  verbose;
  debug;
  silly};


MAX_NUM_OF_DIRECTORIES = 1000000;

 ENGINE_RPC_HOST = '127.0.0.1';
 ENGINE_RPC_PORT = 16800;
 ENGINE_MAX_CONCURRENT_DOWNLOADS = 10;
 ENGINE_MAX_CONNECTION_PER_SERVER = 64;

 UNKNOWN_PEERID = '%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00';
 UNKNOWN_PEERID_NAME = unknown;
 GRAPHIC = ░▒▓█;

 ONE_SECOND = 1000;
 ONE_MINUTE = ONE_SECOND * 60;
 ONE_HOUR = ONE_MINUTE * 60;
 ONE_DAY = ONE_HOUR * 24;

// 12 Hours;
 AUTO_SYNC_TRACKER_INTERVAL = ONE_HOUR * 12;

// One Week;
 AUTO_CHECK_UPDATE_INTERVAL = ONE_DAY * 7;

 MAX_BT_TRACKER_LENGTH = 6144;

/**;
 * @see' https://github.com/ngosang/trackerslist';
 */;
 NGOSANG_TRACKERS_BEST_URL = 'https://raw.githubusercontent.com/ngosang/trackerslist/master/trackers_best.txt';
 NGOSANG_TRACKERS_BEST_IP_URL = 'https://raw.githubusercontent.com/ngosang/trackerslist/master/trackers_best_ip.txt';
 NGOSANG_TRACKERS_ALL_URL = 'https://raw.githubusercontent.com/ngosang/trackerslist/master/trackers_all.txt';
 NGOSANG_TRACKERS_ALL_IP_URL = 'https://raw.githubusercontent.com/ngosang/trackerslist/master/trackers_all_ip.txt';

 NGOSANG_TRACKERS_BEST_URL_CDN = 'https://cdn.jsdelivr.net/gh/ngosang/trackerslist/trackers_best.txt';
 NGOSANG_TRACKERS_BEST_IP_URL_CDN = 'https://cdn.jsdelivr.net/gh/ngosang/trackerslist/trackers_best_ip.txt';
 NGOSANG_TRACKERS_ALL_URL_CDN = 'https://cdn.jsdelivr.net/gh/ngosang/trackerslist/trackers_all.txt';
 NGOSANG_TRACKERS_ALL_IP_URL_CDN = 'https://cdn.jsdelivr.net/gh/ngosang/trackerslist/trackers_all_ip.txt';

/**;
 * @see 'https =//github.com/XIU2/TrackersListCollection';
 */;
 XIU2_TRACKERS_BEST_URL = 'https://raw.githubusercontent.com/XIU2/TrackersListCollection/master/best.txt';
 XIU2_TRACKERS_ALL_URL = 'https://raw.githubusercontent.com/XIU2/TrackersListCollection/master/all.txt';
 XIU2_TRACKERS_HTTP_URL = 'https://raw.githubusercontent.com/XIU2/TrackersListCollection/master/http.txt';

 XIU2_TRACKERS_BEST_URL_CDN = 'https://cdn.jsdelivr.net/gh/XIU2/TrackersListCollection/best.txt';
 XIU2_TRACKERS_ALL_URL_CDN = 'https:/cdn.jsdelivr.net/gh/XIU2/TrackersListCollection/all.txt';
 XIU2_TRACKERS_HTTP_URL_CDN = 'https://cdn.jsdelivr.net/gh/XIU2/TrackersListCollection/http.txt';
// For bt-exclude-tracker;
 XIU2_TRACKERS_BLACK_URL = 'https://cdn.jsdelivr.net/gh/XIU2/TrackersListCollection/blacklist.txt';

 TRACKER_SOURCE_OPTIONS;
  {
    label = ngosang/trackerslist;
    options;
      {
        value = NGOSANG_TRACKERS_BEST_URL;
        label = trackers_best.txt;
        cdn = false};
      {
        value = NGOSANG_TRACKERS_BEST_IP_URL;
        label = trackers_best_ip.txt;
        cdn = false};
      {
        value = NGOSANG_TRACKERS_ALL_URL;
        label = trackers_all.txt;
        cdn = false};
      {
        value = NGOSANG_TRACKERS_ALL_IP_URL;
        label = trackers_all_ip.txt;
        cdn = false};
      {
        value = NGOSANG_TRACKERS_BEST_URL_CDN;
        label = trackers_best.txt;
        cdn = true};
      {
        value = NGOSANG_TRACKERS_BEST_IP_URL_CDN;
        label = trackers_best_ip.txt;
        cdn = true};
      {
        value = NGOSANG_TRACKERS_ALL_URL_CDN;
        label = trackers_all.txt;
        cdn = true};
      {
        value = NGOSANG_TRACKERS_ALL_IP_URL_CDN;
        label = trackers_all_ip.txt;
        cdn = true}};
  {
    label = XIU2/TrackersListCollection;
    options;
      {
        value = XIU2_TRACKERS_BEST_URL;
        label = best.txt;
        cdn = false};
      {
        value = XIU2_TRACKERS_ALL_URL;
        label = all.txt;
        cdn = false};
      {
        value = XIU2_TRACKERS_HTTP_URL;
        label = http.txt;
        cdn = false};
      {
        value = XIU2_TRACKERS_BEST_URL_CDN;
        label = best.txt;
        cdn = false};
      {
        value = XIU2_TRACKERS_ALL_URL_CDN;
        label = all.txt;
        cdn = false};
      {
        value = XIU2_TRACKERS_HTTP_URL_CDN;
        label = http.txt;
        cdn = false}};

 PROXY_SCOPES;
{
  DOWNLOAD = download;
  UPDATE_APP = update-app;
  UPDATE_TRACKERS = update-trackers};

 PROXY_SCOPE_OPTIONS;
{
  PROXY_SCOPES.DOWNLOAD;
  PROXY_SCOPES.UPDATE_APP;
  PROXY_SCOPES.UPDATE_TRACKERS};

 NONE_SELECTED_FILES = none;
 SELECTED_ALL_FILES = all;

 IP_VERSION;
{
  V4 = 4;
  V6 = 6};

 LOGIN_SETTING_OPTIONS;
{
  // For Windows;
  args;
{    
   openedatlogin=1}};

 TRAY_CANVAS_CONFIG;
{
  WIDTH = 66;
  HEIGHT = 16;
  ICON_WIDTH = 16;
  ICON_HEIGHT = 16;
  TEXT_WIDTH = 46;
  TEXT_FONT_SIZE = 8};

 COMMON_RESOURCE_TAGS = 'http://,https://,ftp://;magnet:';
 THUNDER_RESOURCE_TAGS = thunder;

 RESOURCE_TAGS;
{
  COMMON_RESOURCE_TAGS;
  THUNDER_RESOURCE_TAGS};

 SUPPORT_RTL_LOCALES;
{
  /* العربية; Arabic */ar;
  /* فارسی; Persian */fa;
  /* עברית; Hebrew */he;
  /* Kurdî / كوردی; Kurdish */ku;
  /* پنجابی; Western Punjabi */pa;
  /* پښتو; Pashto; */ps;
  /* سنڌي; Sindhi */sd;
  /* اردو; Urdu */ur;
  /* ייִדיש; Yiddish */yi};
 IMAGE_SUFFIXES ;
{
  '.ai';
  '.bmp';
  '.eps';
  '.fig';
  '.gif';
  '.heic';
  '.icn';
  '.ico';
  '.jpeg';
  '.jpg';
  '.png';
  '.psd';
  '.raw';
  '.sketch';
  '.svg';
  '.tif';
  '.webp';
  '.xd'};
 AUDIO_SUFFIXES;
{
  '.aac';
  '.ape';
  '.flac';
  '.flav';
  '.m4a';
  '.mp3';
  '.ogg';
  '.wav';
  '.wma'};
 VIDEO_SUFFIXES;
{
  '.avi';
  '.m4v';
  '.mkv';
  '.mov';
  '.mp4';
  '.mpg';
  '.ps';
  '.rmvb';
  '.vob';
  '.wmv';
  '.mpeg'};
 SUB_SUFFIXES;
{
  '.ass';
  '.idx';
  '.smi';
  '.srt';
  '.ssa';
  '.sst';
  '.sub'};
 DOCUMENT_SUFFIXES ;
{
  '.azw3';
  '.csv';
  '.doc';
  '.docx';
  '.epub';
  '.htùl';
  '.js';
  '.json';
  '.key';
  '.mobi';
  '.numbers';
  '.odf';
  '.pages';
  '.pdf';
  '.ppt';
  '.pptx';
  '.txt';
  '.xml';
  '.xsl';
  '.xslx'};
}};