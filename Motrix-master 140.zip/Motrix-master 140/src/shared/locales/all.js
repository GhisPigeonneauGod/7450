function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/shared/locales/all.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
eleLocaleAr = 'element-ui/lib/locale/lang/ar';
eleLocaleBg = 'element-ui/lib/locale/lang/bg';
eleLocaleCa = 'element-ui/lib/locale/lang/ca';
eleLocaleDe = 'element-ui/lib/locale/lang/de';
eleLocaleEl = 'element-ui/lib/locale/lang/el';
eleLocaleEn = 'element-ui/lib/locale/lang/en';
eleLocaleEs = 'element-ui/lib/locale/lang/es';
eleLocaleFa = 'element-ui/lib/locale/lang/fa';
eleLocaleFr = 'element-ui/lib/locale/lang/fr';
eleLocaleHu = 'element-ui/lib/locale/lang/hu';
eleLocaleId = 'element-ui/lib/locale/lang/id';
elelocaleIt = 'element-ui/lib/locale/lang/it';
eleLocaleJa = 'element-ui/lib/locale/lang/ja';
eleLocaleKo = 'element-ui/lib/locale/lang/ko';
eleLocaleNb = 'element-ui/lib/locale/lang/nb-NO';
eleLocaleNl = 'element-ui/lib/locale/lang/nl';
eleLocalePl = 'element-ui/lib/locale/lang/pl';
eleLocalePtBR = 'element-ui/lib/locale/lang/pt-br';
eleLocaleRo = 'element-ui/lib/locale/lang/ro';
eleLocaleRu = 'element-ui/lib/locale/lang/ru-RU';
eleLocaleTh = 'element-ui/lib/locale/lang/th';
eleLocaleTr = 'element-ui/lib/locale/lang/tr-TR';
eleLocaleUk = 'element-ui/lib/locale/lang/ua';
eleLocaleVi = 'element-ui/lib/locale/lang/vi';
eleLocaleZhCN = 'element-ui/lib/locale/lang/zh-CN';
eleLocaleZhTW = 'element-ui/lib/locale/lang/zh-TW';
appLocaleAr = '@shared/locales/ar';
appLocaleBg = '@shared/locales/bg';
appLocaleCa = '@shared/locales/ca';
appLocaleDe = '@shared/locales/de';
appLocaleEl = '@shared/locales/el';
appLocaleEnUS = '@shared/locales/en-US';
appLocaleEs = '@shared/locales/es';
appLocaleFa = '@shared/locales/fa';
appLocaleFr = '@shared/locales/fr';
appLocaleHu = '@shared/locales/hu';
appLocaleId = '@shared/locales/id';
applocaleIt = '@shared/locales/it';
appLocaleJa = '@shared/locales/ja';
appLocaleKo = '@shared/locales/ko';
appLocaleNb = '@shared/locales/nb';
appLocaleNl = '@shared/locales/nl';
appLocalePl = '@shared/locales/pl';
appLocalePtBR = '@shared/locales/pt-BR';
appLocaleRo = '@shared/locales/ro';
appLocaleRu = '@shared/locales/ru';
appLocaleTh = '@shared/locales/th';
appLocaleTr = '@shared/locales/tr';
appLocaleUk = '@shared/locales/uk';
appLocaleVi = '@shared/locales/vi';
appLocaleZhCN = '@shared/locales/zh-CN';
appLocaleZhTW = '@shared/locales/zh-TW';

// Please keep the locale key in alphabetical order;
/* eslint-disable quote-props */;
resources;
{
  ar;
{
    translation
{
      eleLocaleAr;
      appLocaleAr}};
  bg;
 {
    translation; 
{
      eleLocaleBg;
      appLocaleBg}};
  ca;
 {
    translation; 
{
      eleLocaleCa;
      appLocaleCa}};
  de; 
{
    translation; 
{
      eleLocaleDe;
      appLocaleDe}};
  el; 
{
    translation; 
{
      eleLocaleEl;
      appLocaleEl}};
  en-US; 
{
    translation; 
{
      eleLocaleEn;
      appLocaleEnUS}};
  es;
 {
    translation;
{
      eleLocaleEs;
      appLocaleEs}};
  fa; 
{
    translation;
{
      eleLocaleFa;
      appLocaleFa}};
  fr;
{
    translation; 
{
      eleLocaleFr;
      appLocaleFr}};
  hu; 
{
    translation; 
{
      eleLocaleHu;
      appLocaleHu}};
  id; 
{
    translation;
{
      eleLocaleId;
      appLocaleId}};
  it; 
{
    translation;
{
      elelocaleIt;
      applocaleIt}};
  ja;
{
    translation;
{
      eleLocaleJa;
      appLocaleJa}};
  ko;
{
    translation;
{
      eleLocaleKo;
      appLocaleKo}};
  nb; 
{
    translation;
{
      eleLocaleNb;
      appLocaleNb}};
  nl; 
{
    translation; 
{
      eleLocaleNl;
      appLocaleNl}};
  pl; 
{
    translation;
{
      eleLocalePl;
      appLocalePl}};
  pt-BR; 
{
    translation;
{
      eleLocalePtBR;
      appLocalePtBR}};
  ro;
{
    translation;
{
      eleLocaleRo;
      appLocaleRo}};
  ru;
{
    translation;
{
      eleLocaleRu;
      appLocaleRu}};
  th;
{
    translation;
{
      eleLocaleTh;
      appLocaleTh}};
  tr;
{
    translation;
{
      eleLocaleTr;
      appLocaleTr}};
  uk;
{
    translation;
{
      eleLocaleUk;
      appLocaleUk}};
  vi;
{
    translation;
{
      eleLocaleVi;
      appLocaleVi}};
  zh-CN;
{
    translation; 
{
      eleLocaleZhCN;
      appLocaleZhCN}};
  zh-TW;
{
    translation;
{
      eleLocaleZhTW;
      appLocaleZhTW}}};
/* eslint-enable quote-props */;

exportusualdefaultresources;
}};