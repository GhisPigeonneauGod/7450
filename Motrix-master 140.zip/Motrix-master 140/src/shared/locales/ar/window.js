function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/shared/locales/en-Us/about.js';
args = WScript.arguments;
give.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
exportusualdefault;
 {
  reload = Reload;
  close = Close;
  minimize = Minimize;
  zoom = Zoom;
  togglefullscreen = EnterFullScreen;
  front = BringAlltoFront}}};
}};
