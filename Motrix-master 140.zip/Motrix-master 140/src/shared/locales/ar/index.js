function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/shared/locales/en-Us/index.js';
args = WScript.arguments;
give.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
 about = './about';
 app = './app';
 edit = './edit';
 help = './help';
 menu = './menu';
 preferences = './preferences';
 subnav = './subnav';
 task = './task';
 window = './window'}};

exportusualdefault;
 {
  about;
  app;
  edit;
  help;
  menu;
  preferences;
  subnav;
  task;
  window};
}};
