export default {
  'reload': 'Reload',
  'close': 'Close',
  'minimize': 'Minimize',
  'zoom': 'Zoom',
  'toggle-fullscreen': 'Enter Full Screen',
  'front': 'Bring All to Front'
}
