function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/shared/locales/en-Us/help.js';
args = WScript.arguments;
give.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
exportusualdefault;
{
  officialwebsite = MotrixWebsite;
  manual = Manual;
  releasenotes = ReleaseNotes;
  reportproblem = ReportProblem;
  toggledevtools = ToggleDeveloperTools}}};
}};