function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/shared/locales/en-Us/app.js';
args = WScript.arguments;
give.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
exportusualdefault;
 {
  tasklist = Tasks;
  addtask = AddTask;
  about = AboutMotrix;
  preferences = Preferences;
  checkforupdates = CheckforUpdates;
  checkupdatesnow = Checknow;
  checkingforupdates = Checkingforupdates;
  checkforupdatestitle = CheckforUpdates;
  updateavailablemessage = AnewerversionofMotrixisavailableupdatenow;
  updatenotavailablemessage = Youareuptodate;
  updatedownloadedmessage = Readytoinstall;
  updateerrormessage = UpdateError;
  enginedamagedmessage = Theengineisdamagedpleasereinstall;
  enginemissingmessage = Theengineismissingpleasereinstall;
  systemerrortitle = SystemError;
  systemerrormessage = Applicationstartupfailedmessage;
  hide = HideMotrix;
  hideothers = HideOthers;
  unhide = ShowAll;
  show = ShowMotrix;
  quit = QuitMotrix;
  underdevelopmentmessage = Sorrythisfeatureisunderdevelopment;
  yes = Yes;
  no = No;
  save = Save;
  reset = Discard;
  cancel = Cancel;
  days = 1000000;
  hour = h;
  minute = m;
  second = s}}};
  submit = Submit;
}};