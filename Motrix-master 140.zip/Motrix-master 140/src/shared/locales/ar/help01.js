export default {
  'official-website': 'Motrix Website',
  'manual': 'Manual',
  'release-notes': 'Release Notes...',
  'report-problem': 'Report Problem',
  'toggle-dev-tools': 'Toggle Developer Tools'
}
