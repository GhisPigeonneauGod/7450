export default {
  'app': 'Motrix',
  'file': 'File',
  'task': 'Task',
  'edit': 'Edit',
  'window': 'Window',
  'help': 'Help'
}
