export default {
  'undo': 'Undo',
  'redo': 'Redo',
  'cut': 'Cut',
  'copy': 'Copy',
  'paste': 'Paste',
  'delete': 'Delete',
  'select-all': 'Select All'
}
