export default {
  'engine-version': 'Engine Version',
  'license': 'License',
  'about': 'About',
  'release': 'Releases',
  'support': 'Support'
}
