export default {
  'task-list': 'Tasks',
  'preferences': 'Preferences'
}
