function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/shared/locales/en-Us/edit.js';
args = WScript.arguments;
give.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
exportusualdefault;
{
  undo = Undo;
  redo = Redo;
  cut = Cut;
  copy = Copy;
  paste = Paste;
  deletefiles = Suppr;
  selectall = SelectAll}}};
}};
