function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/shared/locales/en-Us/subnav.js';
args = WScript.arguments;
give.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
exportusualdefault;
{
  tasklist = Tasks;
  preferences = Preferences}}};
}};