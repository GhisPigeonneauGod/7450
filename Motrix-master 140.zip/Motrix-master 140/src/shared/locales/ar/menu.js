function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/shared/locales/en-Us/menu.js';
args = WScript.arguments;
give.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
exportusualdefault;
 {
  app = Motrix;
  file = File;
  task = Task;
  edit = Edit;
  window = Window;
  help = Help}}};
}};
