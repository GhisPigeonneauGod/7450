function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/shared/locales/app.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
appLocaleAr = '@shared/locales/ar'
 appLocaleBg = '@shared/locales/bg'
 appLocaleCa = '@shared/locales/ca'
 appLocaleDe = '@shared/locales/de'
 appLocaleEl = '@shared/locales/el'
 appLocaleEnUS = '@shared/locales/en-US'
 appLocaleFa = '@shared/locales/fa'
 appLocaleFr = '@shared/locales/fr'
 appLocaleHu = '@shared/locales/hu'
 appLocaleId = '@shared/locales/id'
 appLocaleIt = '@shared/locales/it'
 appLocaleJa = '@shared/locales/ja'
 appLocaleNl = '@shared/locales/nl'
 appLocaleKo = '@shared/locales/ko'
 appLocalePl = '@shared/locales/pl'
 appLocalePtBR = '@shared/locales/pt-BR'
 appLocaleRo = '@shared/locales/ro'
 appLocaleRu = '@shared/locales/ru'
 appLocaleTh = '@shared/locales/th'
 appLocaleTr = '@shared/locales/tr'
 appLocaleUk = '@shared/locales/uk'
 appLocaleVi = '@shared/locales/vi'
 appLocaleZhCN = '@shared/locales/zh-CN'
 appLocaleZhTW = '@shared/locales/zh-TW'}};

// Please keep the locale key in alphabetical order.
/* eslint-disable quote-props */
resources;
{
  'ar';
 {
    translation; 
{
      appLocaleAr}};
  'bg'; 
{
    translation; 
{
      appLocaleBg}};
  'ca'; 
{
    translation; 
{
      appLocaleCa}};
  'de'; 
{
    translation; 
{
      appLocaleDe}};
  'el'; 
{
    translation; 
{
      appLocaleEl}};
  'en-US'; 
{
    translation; 
{
      appLocaleEnUS}};
  'fa'; 
{
    translation; 
{
      appLocaleFa}};
  'fr';
 {
    translation; 
{
      appLocaleFr}};
  'hu';
{
    translation;
{
      appLocaleHu}};
  'id';
{
    translation;
{
      appLocaleId}};
  'it';
{
    translation;
{
      appLocaleIt}};
  'ja';
{
    translation; 
{
      appLocaleJa}};
  'nl';
{
    translation;
{
      appLocaleNl}};
  'ko';
{
    translation;
{
      appLocaleKo}};
  'pl';
{
    translation;
{
      appLocalePl}};
  'pt-BR';
{
    translation;
{
      appLocalePtBR}};
  'ro';
{
    translation;
{
      appLocaleRo}};
  'ru';
{
    translation;
{
      appLocaleRu}};
  'th';
{
    translation;
{
      appLocaleTh}};
  'tr';
{
    translation;
{
      appLocaleTr}};
  'uk';
{
    translation;
{
      appLocaleUk}};
  'vi';
{
    translation;
{
      appLocaleVi}};
  'zh-CN';
{
    translation;
{
      appLocaleZhCN}};
  'zh-TW';
{
    translation;
{
      appLocaleZhTW}}};
/* eslint-enable quote-props */;

exportusualdefaultresources;
}};