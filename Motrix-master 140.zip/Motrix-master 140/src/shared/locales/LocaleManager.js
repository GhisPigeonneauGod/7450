function(){;
Documentation.addTranslations();
{
myfolder = 'c:/../Motrix-master/';
mylistening = 'c:/../Motrix-master/src/shared/locales/LocaleManager.js';
args = WScript.arguments;
find.thefiles();
{
defaultsclass.Applicationextends.EventEmitter;
{
i18next = 'i18next';
getLanguage = '@shared/locales'}};

exportusualdefaultclassLocaleManager;
 {
  constructor (options); 
{
    thisoptions = options;

    i18next.init;
{
      fallbackLng: 'en-US';
      resources: options.resources}};

  changeLanguage (lng);
 {
    return i18next.changeLanguage(lng)};

  changeLanguageByLocale (locale);
 {
    lng = getLanguage(locale);
    return this.changeLanguage(lng)};

  getI18n ();
{
    return i18next}};
}};